using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using AutoMapper;
using System.Collections.Generic;
using HUA.Core.Entities;
using HUA.Core.Models;
using HUA.Core.Helpers;

namespace HUA.Core.Modules 
{
    public abstract class CrudModule<D, E, M> 
        : BaseModule<D> 
        where D : DbContext
        where E : class, IEntity, new()
        where M : IEntityModel
    {
        protected IQueryable<E> QueryableBase;

        public CrudModule(D dataContext) 
            : base(dataContext)
        { }

        protected virtual IQueryable<E> ApplyQueryFilter(IQueryable<E> baseQuery, string filters){
            return baseQuery;
        }

        protected virtual IQueryable<E> ApplyJoins(IQueryable<E> baseQuery){
            return baseQuery;
        }

        protected virtual IQueryable<E> ApplyFilters(IQueryable<E> baseQuery, IDictionary<string, string> filters)
        {
            foreach(KeyValuePair<string, string> entry in filters)
            {
                string clave = entry.Key;
                string operador;
                switch (entry.Key[0])
                {
                    case '!':
                        operador = "!=";
                        clave = clave.Substring(1, clave.Length - 1); 
                        break;
                    case '<':
                        operador = "<="; 
                        clave = clave.Substring(1, clave.Length - 1);
                        break;
                    case '>':
                        operador = "!="; 
                        clave = clave.Substring(1, clave.Length - 1);
                        break;
                    default:
                        operador = "=";
                        break;
                }
                System.Reflection.PropertyInfo prop = typeof(E).GetProperty(clave);
                if(prop != null && !String.IsNullOrEmpty(entry.Value)){
                    baseQuery = baseQuery.Where( clave + " " + operador + " @0", entry.Value);
                }
                
            }
            return baseQuery;
        }

        protected virtual IOrderedQueryable<E> ApplySorting(IQueryable<E> baseQuery, SearchBuilder filter)
        {
            // Se necesita eta variable ya que EF diferencia la query sin ningun orden
            // de las que por lo menos tienen un ordenamiento.
            IOrderedQueryable<E> queryBase = null;
            var orderBy = filter.getOrderBy();


            for (int i = 0; i < orderBy.Count(); i++)
            {
                System.Reflection.PropertyInfo prop = typeof(E).GetProperty(orderBy[i].Key);

                // Se diferencia el primer ordenamiento con el resto
                if ( i == 0 ) {
                    if ( orderBy[i].Value.Equals("+") ) {
                        queryBase = baseQuery.OrderBy(x => prop.GetValue(x));
                    } else if (orderBy[i].Value.Equals("-")) {
                        queryBase = baseQuery.OrderByDescending(x => prop.GetValue(x));
                    }
                } else {
                    if ( orderBy[i].Value.Equals("+") ) {
                        queryBase = queryBase.ThenBy( x => prop.GetValue(x) );
                    } else if (orderBy[i].Value.Equals("-")) {
                        queryBase = queryBase.ThenByDescending(x => prop.GetValue(x));
                    }
                }
            }
            
            return queryBase;
        }

        /// <summary>
        /// This method returns a list of entities within the required filters
        /// </summary>
        /// <param name="skip">Quantity of records to skip</param>
        /// <param name="top">Quantity of records to take</param>
        /// <param name="filters">Filters to apply to select registers</param>
        /// <param name="orderBy">Order by columns</param>
        /// <returns>Model with paging information and list of obtained entities models</returns>
        
        public virtual ResultModel<ListModel<M>> GetPage(IDictionary<string, string> queryString)
        {
            ResultModel<ListModel<M>> operationResult;
            

            try
            {
                var queryable = QueryableBase;

                SearchBuilder filter = new SearchBuilder(queryString);

                queryable = ApplyJoins(queryable); 

                queryable = ApplyQueryFilter(queryable, filter._query); 

                queryable = ApplyFilters(queryable, filter._queryString);

                var orderBy = filter.getOrderBy();

                queryable = ApplySorting(queryable, filter);
  
                // get the paged result list
                var model = GetPagedResult<M>(queryable, filter._page, filter._pageSize, filter._query, orderBy);

                operationResult = new SuccessResultModel<ListModel<M>>(model);
            }
            catch(Exception ex)
            {
                operationResult = new ErrorResultModel<ListModel<M>>(ex.Message);
            }

            return operationResult;
        }
        /// <summary>
        /// This method returns an entity model related to certain requested id
        /// </summary>
        /// <param name="id">Id of the entity to retrieve</param>
        /// <returns>Model representation for the entity</returns>
        public ResultModel<M> GetItem(Guid id)
        {
            ResultModel<M> operationResult;

            try
            {
                var entity = QueryableBase.SingleOrDefault(e => e.Id == id);
                var model = Mapper.Map<M>(entity);
                operationResult = new SuccessResultModel<M>(model);
            }
            catch(Exception ex)
            {
                operationResult = new ErrorResultModel<M>(ex.Message);
            }

            return operationResult;
        }

        /// <summary>
        /// This method performs validations to data before trying to insert it
        /// This method MUST be implemented when class is inherited
        /// </summary>
        /// <param name="model">Model with entity information to validate</param>
        /// <returns>ValidationResult / SuccessResult / ErrorResult depending on operation result</returns>
        protected abstract IEnumerable<ErrorModel> CheckCreateValidations(M model);

        /// <summary>
        /// This method performs the mapping between the model and the required entity
        /// This method can be overriden to change it behavior
        /// </summary>
        /// <param name="model">Model with information about entity going to be created</param>
        /// <returns>Entity created with model information</returns>
        public virtual E CreateEntityFromModel(M model)
        {
            return Mapper.Map<E>(model);
        }

        /// <summary>
        /// This method performs the insertion of the requested model to the database
        /// </summary>
        /// <param name="model">Model with entity information to be inserted</param>
        /// <returns>ValidationResult / SuccessResult / ErrorResult depending on operation result</returns>
        public ResultModel<M> Create(M model)
        {
            ResultModel<M> operationResult;

            try
            {
                // perform required validations over model
                var validationErrors = CheckCreateValidations(model);
                if (validationErrors.Any())
                {
                    operationResult = new ErrorResultModel<M>(validationErrors);
                }
                else
                {
                    // map model to entity
                    var entity = CreateEntityFromModel(model);

                    // insert it to database
                    DataContext.Add<E>(entity);
                    DataContext.SaveChanges();

                    // update model with operation generated information
                    model.Id = entity.Id;

                    operationResult = new SuccessResultModel<M>(model);
                }
            }
            catch(Exception ex)
            {
                operationResult = new ErrorResultModel<M>(ex.Message);
            }

            return operationResult;
        }

        /// <summary>
        /// This method performs validations to data before trying to update it
        /// This method MUST be implemented when class is inherited
        /// </summary>
        /// <param name="model"></param>
        /// <returns></returns>
        protected abstract IEnumerable<ErrorModel> CheckUpdateValidations(M model);

        /// <summary>
        /// This method updates entity information with provided model data 
        /// </summary>
        /// <param name="entity">Entity instance to be updated</param>
        /// <param name="model">Model with information to be applied to entity</param>
        protected virtual void UpdateEntityWithModel(E entity, M model)
        {
            Mapper.Map(model, entity);
        }

        /// <summary>
        /// This method updates an entity with provided model information
        /// </summary>
        /// <param name="id">Id of the entity to be updated</param>
        /// <param name="model">Model containing information to be applied to the entity</param>
        /// <returns>ValidationResult / SuccessResult / ErrorResult depending on operation result</returns>
        public ResultModel<M> Update(Guid id, M model)
        {
            ResultModel<M> operationResult;

            try
            {
                // perform required validations over model
                var validationErrors = CheckUpdateValidations(model);
                if (validationErrors.Any())
                {
                    operationResult = new ErrorResultModel<M>(validationErrors);
                }
                else
                {
                    // map model to entity
                    var entity = QueryableBase
                    .FirstOrDefault(e => e.Id == id);

                    if (entity == null)
                    {
                        operationResult = new ErrorResultModel<M>("El registro que intenta modificar no existe");
                    }
                    else
                    {
                        // map model to entity
                        UpdateEntityWithModel(entity, model);

                        // save updated information to database
                        DataContext.SaveChanges();

                        // update model with operation generated information
                        model.Id = entity.Id;

                        operationResult = new SuccessResultModel<M>(model);
                    }
                }
            }
            catch(Exception ex)
            {
                operationResult = new ErrorResultModel<M>(ex.Message);
            }

            return operationResult;
        }

        protected abstract IEnumerable<ErrorModel> CheckDeleteValidations(Guid model);

        public ResultModel<Guid> Delete(Guid id)
        {
            ResultModel<Guid> operationResult;

            try
            {
                // perform required validations over model
                var validationErrors = CheckDeleteValidations(id);
                if (validationErrors.Any())
                {
                    operationResult = new ErrorResultModel<Guid>(validationErrors);
                }
                else
                {
                    // map model to entity
                    var entity = QueryableBase
                    .FirstOrDefault(e => e.Id == id);

                    if (entity == null)
                    {
                        operationResult = new ErrorResultModel<Guid>("El registro que intenta eliminar no existe");
                    }
                    else
                    {
                        // remove the entity
                        DataContext.Remove(entity);

                        // save updated information to database
                        DataContext.SaveChanges();

                        operationResult = new SuccessResultModel<Guid>(id);
                    }
                }
            }
            catch (Exception ex)
            {
                operationResult = new ErrorResultModel<Guid>(ex.Message);
            }

            return operationResult;
        }
    }
}