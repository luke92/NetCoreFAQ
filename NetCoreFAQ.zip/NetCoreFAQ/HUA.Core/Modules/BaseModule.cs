using AutoMapper.QueryableExtensions;
using HUA.Core.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;
using System.Linq.Dynamic.Core;
using System.Collections.Generic;

namespace HUA.Core.Modules 
{
    public abstract class BaseModule<D> where D: DbContext {
        protected D DataContext;

        public BaseModule(D dataContext) {
            DataContext = dataContext;
        }

        /// <summary>
        /// This generic method provides the functionality
        /// of generating paged result from a queriable list
        /// and paging params
        /// </summary>
        /// <typeparam name="T">Data type of the expected result list</typeparam>
        /// <param name="queryable">Queryable list to be paged</param>
        /// <param name="page">Page to be returned</param>
        /// <param name="pageSize">Size of the page to be returned</param>
        /// <param name="filters">Filters applied to the list (only for feedback)</param>
        /// <param name="orderBy">Order applied to the list (only for feedback)</param>
        /// <returns></returns>
        protected ListModel<T> GetPagedResult<T>(IQueryable queryable, 
            int page = 1, int pageSize = 10, 
            string filters = null, List<KeyValuePair<string, string>> orderBy = null)
        {
            // get query total count and requested page
            var skip = (page - 1) * pageSize;
            var count = queryable.Count();
            var result = queryable.Skip(skip).Take(pageSize);

            // construct the response
            var model = new ListModel<T>();
            model.Page = page;
            model.Pages = (int)Math.Ceiling((decimal)count / pageSize);
            model.PageSize = pageSize;
            model.Count = count;
            model.Filter = filters;
            model.OrderBy = orderBy;
            model.Items = result.ProjectTo<T>().ToList();

            return model;
        }
    }
}