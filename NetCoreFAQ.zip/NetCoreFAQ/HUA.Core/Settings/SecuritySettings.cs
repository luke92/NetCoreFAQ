﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HUA.Core.Settings
{
    public class SecuritySettings
    {
        public string RegistrationUri { get; set; }
        public string AuthenticateUri { get; set; }
        public string Codigo { get; set; }
        public string[] Perfiles { get; set; }
    }
}
