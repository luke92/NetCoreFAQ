﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel.DataAnnotations;

namespace HUA.Core.Entities
{
    public class HUAEntity : IEntity, IDeleteable
    {
        [Key]
        public Guid Id { get; set; }

        public DateTime CreatedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string CreatedUser { get; set; }
        public string UpdateUser { get; set; }
        public string DeletedUser { get; set; }

        public HUAEntity()
        {            
            CreatedDate = DateTime.Now;
            ModifiedDate = DateTime.Now;
            DeletedDate = null;

            Deleted = false;
        }

        public void Delete()
        {
            Deleted = true;
            DeletedDate = DateTime.Now;
        }

        #region IDeleteable Members
        public bool Deleted { get; set; }
        public DateTime? DeletedDate { get; set; }
        #endregion
    }
}
