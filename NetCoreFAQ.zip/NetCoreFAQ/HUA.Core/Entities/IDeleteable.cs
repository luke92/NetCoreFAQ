﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HUA.Core.Entities
{
    public interface IDeleteable
    {
        bool Deleted { get; set; }
        DateTime? DeletedDate { get; set; }
    }
}
