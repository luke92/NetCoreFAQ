﻿using System;

namespace HUA.Core.Entities
{
    public class Log: HUAEntity
    {
        public string Controller { get; set; }
        public string Action { get; set; }
        public string Method { get; set; }
        public string Parameters { get; set; }
        public Guid UserId { get; set; }
        public string UserName { get; set; }
    }
}
