﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HUA.Core.Entities
{
    public interface IEntity
    {
        Guid Id { get; set; }
    }
}
