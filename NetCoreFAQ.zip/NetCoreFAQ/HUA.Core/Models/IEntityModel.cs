﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HUA.Core.Models
{
    public interface IEntityModel
    {
        Guid Id { get; set; }
    }
}
