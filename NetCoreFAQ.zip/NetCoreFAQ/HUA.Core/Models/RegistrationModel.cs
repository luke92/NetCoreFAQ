﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HUA.Core.Models
{
    public class RegistrationModel
    {
        public string Codigo { get; set; }
        public string[] Perfiles { get; set; }
    }
}
