﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HUA.Core.Models
{
    public sealed class OperationContext : IOperationContext
    {
        /// <summary>
        /// Returns current logged user id or empty guid if there is no logged user
        /// </summary>
        public Guid UserId { get; set; }

        /// <summary>
        /// Returns current logged user email or null if there is no logged user
        /// </summary>
        public string Email { get; set; }

        /// <summary>
        /// Returns current logged user legajo or null if there is no logged user
        /// </summary>
        public string Legajo { get; set; }

        /// <summary>
        /// Returns current logged rol id or empty guid if there is no logged user
        /// </summary>
        public string[] Roles { get; set; }
    }
}
