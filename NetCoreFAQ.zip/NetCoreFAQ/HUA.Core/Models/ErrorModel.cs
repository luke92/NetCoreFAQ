﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HUA.Core.Models
{
    public class ErrorModel
    {
        public string Source { get; set; }
        public string Message { get; set; }

        public ErrorModel(string source, string message)
        {
            Source = source;
            Message = message;
        }
    }
}
