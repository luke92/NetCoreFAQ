﻿using System;

namespace HUA.Core.Models
{
    public interface IOperationContext
    {
        string Email { get; set; }
        string[] Roles { get; set; }
        Guid UserId { get; set; }
        string Legajo { get; set; }
    }
}