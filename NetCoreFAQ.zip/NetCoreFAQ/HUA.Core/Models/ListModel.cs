using System;
using System.Collections.Generic;

namespace HUA.Core.Models 
{
    public class ListModel<T> {
        public List<KeyValuePair<string, string>> OrderBy { get; set; }
        public string Filter { get; set; }
        public int Count { get; set; }
        public int Page { get; set; }
        public int Pages { get; set; }
        public int PageSize { get; set; }
        public IEnumerable<T> Items { get; set; }
    }
}