﻿using System;
using System.Collections.Generic;
using System.DirectoryServices;
using System.DirectoryServices.ActiveDirectory;
using System.Text;

namespace HUA.Core.Helpers
{
    public class ActiveDirectoryHelper
    {
        public string LdapServerUrl { get; protected set; }
        private string filterAttribute;

        public ActiveDirectoryHelper(string ldapServerUrl)
        {
            this.LdapServerUrl = ldapServerUrl;
        }

        public List<String> GetActiveDirectoryUsers(SamName samName, string password)
        {
            if (samName == null || string.IsNullOrWhiteSpace(password))
                return new List<string>();

            try
            {
                //we try to resolve the LDAP full name given it's frindly name.
                string ldapDomain;
                if (!TryGetLdapDomain(samName.DomainName, samName.UserName, password, out ldapDomain))
                    return new List<string>();

                // prepare the query
                var entry = new DirectoryEntry
                    (
                    string.Format("{0}/{1}", LdapServerUrl, ldapDomain),
                    samName.UserName,
                    password
                    );
                DirectorySearcher adSearch = new DirectorySearcher(entry);
                adSearch.SearchScope = SearchScope.Subtree;
                adSearch.PageSize = 10000;
                adSearch.Filter = "(&(objectClass=user))";
                SearchResultCollection sColl = adSearch.FindAll();

                foreach (SearchResult sResult in sColl)
                {
                    string sConn = sResult.Properties["distinguishedName"][0].ToString();
                    DirectoryEntry dirEnt2 = new DirectoryEntry("LDAP://" + sConn);
                }
            }
            catch
            {
            }

            return new List<string>();
        }

        public bool AuthenticateUser(SamName samName, string password)
        {
            if (samName == null || string.IsNullOrWhiteSpace(password))
                return false;

            try
            {
                //we try to resolve the LDAP full name given it's frindly name.
                string ldapDomain;
                if (!TryGetLdapDomain(samName.DomainName, samName.UserName, password, out ldapDomain))
                    return false;

                // prepare the query
                var entry = new DirectoryEntry
                                (
                                    string.Format("{0}/{1}", LdapServerUrl, ldapDomain),
                                    samName.UserName,
                                    password
                                );

                // perform the search 
                var search = new DirectorySearcher(entry)
                {
                    Filter = string.Format("(SAMAccountName={0})", samName.UserName)
                };

                search.PropertiesToLoad.Add("cn");
                var result = search.FindOne();

                // if user were not found, return false
                if (null == result)
                    return false;

                LdapServerUrl = result.Path;
                filterAttribute = (String)result.Properties["cn"][0];

                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
        }

        public String GetGroups()
        {
            DirectorySearcher search = new DirectorySearcher(LdapServerUrl);
            search.Filter = "(cn=" + filterAttribute + ")";
            search.PropertiesToLoad.Add("memberOf");
            StringBuilder groupNames = new StringBuilder();

            try
            {
                SearchResult result = search.FindOne();

                int propertyCount = result.Properties["memberOf"].Count;

                String dn;
                int equalsIndex, commaIndex;

                for (int propertyCounter = 0; propertyCounter < propertyCount; propertyCounter++)
                {
                    dn = (String)result.Properties["memberOf"][propertyCounter];

                    equalsIndex = dn.IndexOf("=", 1);
                    commaIndex = dn.IndexOf(",", 1);
                    if (-1 == equalsIndex)
                    {
                        return null;
                    }

                    groupNames.Append(dn.Substring((equalsIndex + 1), (commaIndex - equalsIndex) - 1));
                    groupNames.Append("|");

                }
            }
            catch (Exception ex)
            {
                throw new Exception("Error obtaining group names. " + ex.Message);
            }
            return groupNames.ToString();
        }

        public static bool IsValidUser(string userName)
        {
            SamName name;
            return SamName.TryCreate(userName, out name);
        }

        private bool TryGetLdapDomain(string friendlyName, string userName, string password, out string ldapDomain)
        {
            ldapDomain = string.Empty;

            try
            {
                var objContext = new DirectoryContext(DirectoryContextType.Domain, friendlyName, userName, password);
                var objDomain = Domain.GetDomain(objContext);

                var parts = objDomain.Name.Split('.');

                if (parts.Length == 0)
                    return false;

                const string pattern = "DC={0},";
                foreach (var part in parts)
                {
                    ldapDomain += string.Format(pattern, part);
                }

                int lenght = ldapDomain.Length;
                ldapDomain = ldapDomain.Remove(lenght - 1, 1);

                return true;
            }
            catch
            {
                return false;
            }
        }
    }

    public class SamName
    {
        public string DomainName { get; private set; }
        public string UserName { get; private set; }

        public static bool TryCreate(string input, out SamName samName)
        {
            samName = null;

            try
            {
                if (string.IsNullOrWhiteSpace(input))
                    return false;

                var parts = input.Split('\\');

                var domainName = parts[0];
                var userName = parts[1];

                samName = new SamName { DomainName = domainName, UserName = userName };
                return true;
            }
            catch
            {
                return false;
            }
        }
    }
}
