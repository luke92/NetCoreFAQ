using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace HUA.Core.Helpers
{
    public class SearchBuilder
    {
        public int _pageSize { get; private set;} = 10;
        public int _page { get; private set;} = 1;
        private string _orderBy { get; set;} = "-CreatedDate";
        public string _query { get; private set;} = "";
        public IDictionary<string, string> _queryString { get; private set;}
        public SearchBuilder(IDictionary<string, string> queryString)
        { 

            if (queryString.ContainsKey("pageSize") && !string.IsNullOrWhiteSpace(queryString["pageSize"]) ) {
                _pageSize = Int32.Parse( queryString["pageSize"] );
                queryString.Remove("pageSize");
            }

            if (queryString.ContainsKey("page") && !string.IsNullOrWhiteSpace(queryString["page"]) ) {
                _page = Int32.Parse( queryString["page"] );
                queryString.Remove("page");
            }

            if (queryString.ContainsKey("orderBy")) {
                if( !string.IsNullOrWhiteSpace(queryString["orderBy"])) {
                    _orderBy = queryString["orderBy"].Trim();
                }
                queryString.Remove("orderBy");
            }

            if (queryString.ContainsKey("query") && !string.IsNullOrWhiteSpace(queryString["query"]) ) {
                _query = queryString["query"];
                queryString.Remove("query");
            }

            _queryString = queryString;
        }
        

        // Retorna el campo por el cual se ordena
        public List<KeyValuePair<string, string>> getOrderBy(){

            string[] listaOrdenes = new string[]{
                    _orderBy
                };

            if ( _orderBy.Contains(",") ) {
                listaOrdenes = _orderBy.Split(",");
            } 

            List<KeyValuePair<string, string>> aux = new List<KeyValuePair<string, string>>();
            for (int i = 0; i < listaOrdenes.Length; i++)
            {
                KeyValuePair<string, string> single;
                string dato = listaOrdenes[i].Trim();
                if( isNewFormOrderBy(dato) ){
                    //Devuelvo toda la cadena exepto el primer caracter
                    string valor = dato.Substring(0,1);
                    string clave = dato.Substring(1, dato.Length - 1 );
                    
                    single = new KeyValuePair<string, string>(clave, valor);
                }else{
                    single  = new KeyValuePair<string, string>( dato, "+");
                }
                aux.Add(single);
            }
            return aux;
        }

        // Retorna el valor del parametro con key pasada por parametro
        public string getParametro(string key){
            if ( _queryString.ContainsKey(key) ){
                return _queryString[key];
            }
            return String.Empty;
        }

        public Boolean hasParametro(string key){
            if ( _queryString.ContainsKey(key) ){
                return true;
            }
            return false;
        }
        
        public void addParametro(string key, string value){
            if ( _queryString.ContainsKey(key) ){
                _queryString.Add(new KeyValuePair<string,string>(key, value));
            }else{
                _queryString[key] = value;
            }
        }

        private Boolean isNewFormOrderBy(string dato)
        {
            char firstChar = dato.ToCharArray()[0];
            return (firstChar.Equals('-') || firstChar.Equals('+'));
        }
        
    }

    
}
