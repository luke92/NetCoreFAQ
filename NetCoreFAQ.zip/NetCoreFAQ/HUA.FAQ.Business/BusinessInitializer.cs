﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using AutoMapper;
using HUA.Core.Models;
using HUA.Core.Settings;
using HUA.EstructuraHospitalaria.Business;
using HUA.FAQ.Business.Modules.Category.Models;
using HUA.FAQ.Business.Modules.Faq.Models;
using HUA.FAQ.Business.Modules.Tag.Models;
using HUA.FAQ.Data;
using HUA.FAQ.Data.Entities;

namespace HUA.FAQ.Business
{
    public static class BusinessInitializer
    {
        public static void InitializeDatabase(FAQContext context)
        {
            // ensure database exists
            context.Database.EnsureCreated();

            #region Category
            Category firstCategory = new Category{ Id = Guid.NewGuid(), Name = "Desarrollo"};
            if (!context.Categories.Any())
            { 
                context.Categories.AddRange(
                   firstCategory
                );
            }
            #endregion

            #region Tag
            Tag firstTag = new Tag(){Id = Guid.NewGuid(), Name = "React"};
            if (!context.Categories.Any()) 
            {
                context.Tags.AddRange(
                    firstTag,
                    new Tag(){Id = Guid.NewGuid(), Name = "JavaScript"}
                );
            }
            #endregion

            #region FAQ
            if (!context.FAQs.Any())
            {   
                Data.Entities.FAQ faq = new Data.Entities.FAQ(){
                    Id = Guid.NewGuid(),
                    Category = firstCategory,
                    Name = "Como iniciar un proyecto con React",
                    Description = "Iniciando con React",
                    Solution = "Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt. Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur?",
                    Visits = 30,
                    CreatedUser = "Admin"
                };
                context.FAQs.Add(faq);
                
                context.FaqTags.Add(
                    new FAQTag(){ FAQ = faq, Tag = firstTag}
                );
            }
            #endregion

            context.SaveChanges();
        }

        public static void InitializeMappings()
        {
            Mapper.Initialize(cfg =>
            {

                cfg.CreateMap<Category, CategoryModel>()
                    .ForMember(b => b.Faqs, opt => opt.MapFrom(b => b.faqs))
                    .ReverseMap();
                    
                cfg.CreateMap<Tag, TagModel>()
                    .ReverseMap();

                cfg.CreateMap<Data.Entities.FAQ, FaqModel>()
                    .ForMember(model => model.Tags, entity =>
                                         entity.MapFrom(x => x.FaqTags.Select(y => y.Tag)))
                    .ForMember(model => model.Category, entity => entity.MapFrom(x => new CategoryModel()
                                                                                    {
                                                                                       Id = x.Category.Id,
                                                                                       Name = x.Name
                                                                                    }));

                cfg.CreateMap<FaqModel, Data.Entities.FAQ>()
                    .ForMember(entity => entity.FaqTags, model =>
                        model.MapFrom(x => x.Tags.Select(t => new FAQTag()
                        {
                            TagId = t.Id,
                            FAQId = x.Id,
                        })))
                    .ForMember(model => model.CreatedDate, entity => entity.Ignore())
                    .ForMember(entity => entity.Category, model => model.MapFrom(
                        x => new Category()
                        {
                            Id = x.Category.Id
                        }
                    ));



            });
        }

        public static void RegisterApplicationInSecurityServer(SecuritySettings settings, ISeguridadService registerSeguridadService)
        {
            registerSeguridadService.Register(settings);
        }

    }
}
