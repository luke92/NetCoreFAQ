﻿using System.Threading.Tasks;
using HUA.Core.Models;
using HUA.Core.Settings;
using HUA.FAQ.Business.Modules.Authentication.Models;

namespace HUA.EstructuraHospitalaria.Business
{
    public interface ISeguridadService
    {
        void Register(SecuritySettings settings);

        Task<ResultModel<AuthenticationResultModel>> securityAuthenticationAsync(string URL, AuthenticationModel model);
    }

}
