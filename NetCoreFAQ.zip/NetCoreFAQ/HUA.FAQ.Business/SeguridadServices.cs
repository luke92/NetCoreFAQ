﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using HUA.Core.Models;
using HUA.Core.Settings;
using HUA.FAQ.Business.Modules.Authentication.Models;

namespace HUA.EstructuraHospitalaria.Business
{
    public class SeguridadService : ISeguridadService
    {
        public async void Register(SecuritySettings settings)
        {
            Console.WriteLine($"Settings:\n Codigo: {settings.Codigo}\n Register Uri: {settings.RegistrationUri}");
            using (HttpClient client = new HttpClient())
            {
                var appData = new RegistrationModel
                {
                    Codigo = settings.Codigo,
                    Perfiles = settings.Perfiles
                };

                var response = await client.PostAsJsonAsync<RegistrationModel>(settings.RegistrationUri, appData);

                if (!response.IsSuccessStatusCode)
                {
                    var error = await response.Content.ReadAsStringAsync();

                    throw new ApplicationException(
                        $"An error ocurred trying to register application at security server.\n" +
                        $"Server: '{settings.RegistrationUri}'\n" +
                        $"Code: '{settings.Codigo}'\n" +
                        $"Profiles: '{String.Join(", ", settings.Perfiles)}'\n" +
                        $"Error Code: '{response.StatusCode}'\n" +
                        $"Error Message: '{response.ReasonPhrase}'\n" +
                        $"Error Description: '{error}'"
                    );
                }
            }
        }

        public async Task<ResultModel<AuthenticationResultModel>> securityAuthenticationAsync(string url, AuthenticationModel model)
        {

            ResultModel<AuthenticationResultModel> result;

            using (HttpClient client = new HttpClient())
            {
                HttpResponseMessage apiRequest = await client.PostAsJsonAsync<AuthenticationModel>(url, model);

                // ¿La autenticación fue correcta?
                if (apiRequest.IsSuccessStatusCode)
                {
                    result = new SuccessResultModel<AuthenticationResultModel>(await apiRequest.Content.ReadAsAsync<AuthenticationResultModel>());
                }
                else
                {
                    var error = await apiRequest.Content.ReadAsStringAsync();

                    result = new ErrorResultModel<AuthenticationResultModel>(error);
                }
            }

            return result;
        }
    }
}
