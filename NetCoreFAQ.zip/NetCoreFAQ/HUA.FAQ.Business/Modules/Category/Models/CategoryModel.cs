﻿using System;
using System.Collections.Generic;
using System.Text;
using HUA.Core.Models;
using HUA.FAQ.Business.Modules.Faq.Models;

namespace HUA.FAQ.Business.Modules.Category.Models
{
    public class CategoryModel : GenericModel
    {
        public string Name { get; set; }
        public List<FaqModel> Faqs { get; set; }
    }
}
