﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HUA.Core.Models;
using HUA.Core.Modules;
using HUA.FAQ.Business.Modules.Category.Models;
using HUA.FAQ.Data;
using AutoMapper.QueryableExtensions;

namespace HUA.FAQ.Business.Modules.Category
{
    /*
     * La clase abstract "CrudModule" presenta la mayoría de los métodos necesarios a la hora de
     * realizar un crud. Para su correcto uso, es necesario sobrescribir los métodos de validación.
     * Además, es posible (en caso de ser necesario), reimplementar los métodos de filtro.
     */
    public class CategoryModule : CrudModule<FAQContext, Data.Entities.Category, CategoryModel>
    {
        private FAQContext _context;
        public CategoryModule(FAQContext context) : base (context)
        {
            /*
             * Dicha propiedad hay que asignarla debido a que la clase abstracta "padre"
             * la emplea para realizar las consultas que constituyen el CRUD
             */
            QueryableBase = context.Set<Data.Entities.Category>().AsQueryable();
            _context = context;
        }


        /*
         * Método que tiene como fin llevar a cabo la validación sobre el modelo al momento
         * de crearlo. Se devuelve un listado del tipo "ErrorModel", con el objetivo de describir
         * los mismos.
         * TIP: Notar el uso de la palabra reservada "yield", que permite ir acumulando la devolución
         * sin retornar la respuesta hasta no llegar al final del bloque.
         */
        protected override IEnumerable<ErrorModel> CheckCreateValidations(CategoryModel model)
        {
            

            if (string.IsNullOrWhiteSpace(model.Name) || model.Name.Length < 3)
                yield return new ErrorModel("Name", "El nombre es requerido y debe tener al menos 3 caracteres");

            var existCategory = DataContext.Categories.FirstOrDefault(x => x.Name == model.Name);

            if (existCategory != null)
                yield return new ErrorModel("Name", "El nombre ya existe");
        }

        protected override IEnumerable<ErrorModel> CheckDeleteValidations(Guid model)
        {
            var categoryInUse = DataContext.FAQs.Any(x => x.Category.Id == model);

            if (categoryInUse)
                yield return new ErrorModel("Name", "La cateogria no puede eliminarse por que está en uso");
        }

        protected override IEnumerable<ErrorModel> CheckUpdateValidations(CategoryModel model)
        {
            return CheckCreateValidations(model);
        }
    }
}
