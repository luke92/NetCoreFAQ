﻿using System;
using System.Net.Mail;
using System.ServiceModel;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using HUA.FAQ.Business.Modules.Faq.Models;
using HUA.FAQ.Business.Modules.Mail;
using MailServiceReference;

namespace HUA.FAQ.Business.Modules.Faq
{
    public class MailModule : IMailModule
    {
        private readonly IConfiguration _configuration;
        private readonly IMailsService _mailsService;
        public MailModule(IConfiguration configuration)
        {
            _configuration = configuration;
            _mailsService = new MailsServiceClient(MailsServiceClient.EndpointConfiguration.MailsServiceEndpoint, new EndpointAddress(_configuration["MAIL:EndPoint"]));
        }
        public async Task<bool> SendFaqCreateAsync(FaqModel faqModel)
        {
            try
            {
                string url = _configuration["MAIL:UrlFaqBase"] + faqModel.Id.ToString();
                string subject = "Creación de FAQ " + faqModel.Name;
                string body = "Creación de FAQ " + faqModel.Name + "\n";
                body += faqModel.Description + "\n";
                body += url + "\n";
                body += "Saludos";
                return await SendEmail(subject, body);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return false;
            }
        }

        public async Task<bool> SendFaqUpdateAsync(FaqModel faqModel)
        {
            try
            {
                string url = _configuration["MAIL:UrlFaqBase"] + faqModel.Id;
                string subject = "Actualización de FAQ " + faqModel.Name;
                string body = "Actualización de FAQ " + faqModel.Name + "\n";
                body += faqModel.Description + "\n";
                body += url + "\n";
                body += "Saludos";
                return await SendEmail(subject, body);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return false;
            }
        }

        private async Task<bool> SendEmail(string subject, string body)
        {
            try
            {
                var destinatario = new DestinatarioToSendModel()
                {
                    Id = Guid.NewGuid(),
                    Apellido = _configuration["MAIL:Apellido"],
                    Nombre = _configuration["MAIL:Nombre"],
                    DestinatarioId = Guid.NewGuid(),
                    Breadcrumb = "",
                    Tabs = Array.Empty<TabModel>(),
                    Correo = _configuration["MAIL:To"]
                };
                var destinatarios = new[] {destinatario};
                await _mailsService.AddMailToSendAsync(new MailToSendModel()
                {
                    Id = Guid.NewGuid(),
                    Tabs = Array.Empty<TabModel>(),
                    AplicacionId = Guid.NewGuid(),
                    EmisorId = Guid.NewGuid(),
                    ResponderA = _configuration["MAIL:To"],
                    Subject = subject,
                    NombreEmisor = _configuration["MAIL:From"],
                    Destinatarios = destinatarios,
                    Body = body,
                });
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
                return false;
            }

        }
    }
}
