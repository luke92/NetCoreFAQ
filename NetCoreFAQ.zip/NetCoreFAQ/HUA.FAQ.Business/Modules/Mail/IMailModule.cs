﻿using System.Threading.Tasks;
using HUA.FAQ.Business.Modules.Faq.Models;

namespace HUA.FAQ.Business.Modules.Mail
{
    public interface IMailModule
    {
        Task <bool> SendFaqCreateAsync(FaqModel faqModel);

        Task<bool> SendFaqUpdateAsync(FaqModel faqModel);
    }
}
