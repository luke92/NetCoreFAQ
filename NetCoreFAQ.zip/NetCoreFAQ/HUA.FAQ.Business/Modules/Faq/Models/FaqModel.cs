﻿using System;
using System.Collections.Generic;
using System.Text;
using HUA.Core.Models;
using HUA.FAQ.Business.Modules.Category.Models;
using HUA.FAQ.Business.Modules.Tag.Models;
using HUA.FAQ.Data.Entities;

namespace HUA.FAQ.Business.Modules.Faq.Models
{
    public class FaqModel : GenericModel
    {
        public string Name { get; set; }
        public string Description { get; set; }
        public string Solution { get; set; }
        public int Visits { get; set; }
        public int Rating { get; set; }
        public CategoryModel Category { get; set; }
        public DateTime CreatedDate { get; set; }
        public List<TagModel> Tags { get; set; }
    }
}
