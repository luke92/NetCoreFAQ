﻿using System;
using System.Collections.Generic;
using System.Linq;
using HUA.Core.Models;
using HUA.Core.Modules;
using HUA.FAQ.Business.Modules.Faq.Models;
using HUA.FAQ.Data;
using Microsoft.EntityFrameworkCore;
using AutoMapper;
using HUA.Core.Helpers;
using HUA.FAQ.Business.Modules.Mail;

namespace HUA.FAQ.Business.Modules.Faq
{
    public class FaqModule : CrudModule<FAQContext, Data.Entities.FAQ, FaqModel>
    {
        private IMailModule _mailModule;
        public FaqModule(FAQContext context, IMailModule mailModule) : base(context)
        {
            _mailModule = mailModule;
            /*
             * Dicha propiedad hay que asignarla debido a que la clase abstracta "padre"
             * la emplea para realizar las consultas que constituyen el CRUD
             */
            QueryableBase = context.Set<Data.Entities.FAQ>()
                                                            .Include(x => x.Category)
                                                            .Include(x => x.FaqTags)
                                                            .ThenInclude(t => t.Tag)
                                                            .AsQueryable();
        }
        protected override IEnumerable<ErrorModel> CheckCreateValidations(FaqModel model)
        {
            if (string.IsNullOrWhiteSpace(model.Name) || model.Name.Length < 3)
                yield return new ErrorModel("Name", "El nombre es requerido y debe tener al menos 3 caracteres");

            if (model.Category == null ||
                (model.Category != null &&
                    (model.Category.Id == null || model.Category.Id == Guid.Empty)))
                yield return new ErrorModel("Category", "La categoría es requerida");

            var existFaq = DataContext.FAQs.FirstOrDefault(x => x.Name == model.Name);

            if (existFaq != null)
                yield return new ErrorModel("Name", "El nombre ya existe");
        }

        protected override IEnumerable<ErrorModel> CheckDeleteValidations(Guid model)
        {
            
            var faqExist = DataContext.FAQs.Any(x => x.Id == model);
            if (!faqExist)
                yield return new ErrorModel("Faq", "El Faq que quiere borrar no Existe.");
            //if (categoryInUse)
            //    yield return new ErrorModel("Name", "La cateogria no puede eliminarse por que está en uso");
        }

        protected override IEnumerable<ErrorModel> CheckUpdateValidations(FaqModel model)
        {
            if (string.IsNullOrWhiteSpace(model.Name) || model.Name.Length < 3)
                yield return new ErrorModel("Name", "El nombre es requerido y debe tener al menos 3 caracteres");

            if (model.Category == null ||
                (model.Category != null &&
                 (model.Category.Id == null || model.Category.Id == Guid.Empty)))
                yield return new ErrorModel("Category", "La categoría es requerida");

            var existFaq = DataContext.FAQs.FirstOrDefault(x => x.Name == model.Name);

            if (existFaq != null && existFaq.Id != model.Id) 
               yield return new ErrorModel("Name", "El nombre ya existe");
        }


        public override Data.Entities.FAQ CreateEntityFromModel(FaqModel model)
        {
            Data.Entities.FAQ currentFaq = base.CreateEntityFromModel(model);
            this.DataContext.Entry(currentFaq.Category).State = EntityState.Unchanged;
            _mailModule.SendFaqCreateAsync(model);
            return currentFaq;
        }

        protected override void UpdateEntityWithModel(Data.Entities.FAQ entity, FaqModel model)

        {
            var local = DataContext.Set<Data.Entities.Category>()
                .Local
                .FirstOrDefault(entry => entry.Id.Equals(entity.Category.Id));

            if (local != null) 
            {
                // detach
                DataContext.Entry(local).State = EntityState.Detached;
            }

            base.UpdateEntityWithModel(entity, model);

            this.DataContext.Entry(entity.Category).State = EntityState.Unchanged;
            _mailModule.SendFaqUpdateAsync(model);
        }

        protected override IOrderedQueryable<Data.Entities.FAQ> ApplySorting(IQueryable<Data.Entities.FAQ> baseQuery,
            SearchBuilder filter)
        {
            if (string.IsNullOrWhiteSpace(filter._query))
            {
                return base.ApplySorting(baseQuery, filter);
            }
            
            return baseQuery.OrderBy(q =>
                q.Name.IndexOf(filter._query, StringComparison.InvariantCultureIgnoreCase) > 0
                    ? q.Name.IndexOf(filter._query, StringComparison.InvariantCultureIgnoreCase)
                    : 99999);

        }

        protected override IQueryable<Data.Entities.FAQ> ApplyQueryFilter(IQueryable<Data.Entities.FAQ> baseQuery, string query){
            return baseQuery.Where(x => (x.Name.ToLower().Contains(query)
                                                  || x.Solution.ToLower().Contains(query))
                                                  || x.FaqTags.Any(t => t.Tag.Name.Contains(query)));
        }

        protected override IQueryable<Data.Entities.FAQ> ApplyFilters(IQueryable<Data.Entities.FAQ> baseQuery, IDictionary<string, string> filters)
        {
            filters.TryGetValue("TagId", out var tagValue);
            if ( !String.IsNullOrWhiteSpace(tagValue)) {
                Guid id = Guid.Parse(filters["TagId"]);
                baseQuery = baseQuery.Where(f => f.FaqTags.Any(ft => ft.TagId.Equals(id)));
                filters.Remove("TagId");
            }

            filters.TryGetValue("RelatedId", out var relatedValue);
            if ( !String.IsNullOrWhiteSpace(relatedValue)) {
                Guid id = Guid.Parse(filters["RelatedId"]);
                List<Guid> tagList = DataContext.Tags.Where(t => t.FaqTags.Any(ft => ft.FAQId.Equals(id))).Select(x => x.Id).ToList();
                baseQuery = baseQuery.Where(x => x.FaqTags.Any(ft => tagList.Contains(ft.TagId)));
                filters.Remove("RelatedId");
            }

            baseQuery = base.ApplyFilters(baseQuery, filters);

            return baseQuery;
        }

        public ResultModel<FaqModel> AddVisit(string id )
        {
            Data.Entities.FAQ entity;
            entity = Guid.TryParse(id, out var idGuid) ? 
                QueryableBase.SingleOrDefault(e => e.Id == idGuid) : 
                QueryableBase.SingleOrDefault(e => e.Name == id);

            if (entity != null)
            {
                entity.Visits += 1;
                var model = Mapper.Map<FaqModel>(entity);
                DataContext.SaveChanges();

                var operationResult = new SuccessResultModel<FaqModel>(model);
                return operationResult;
            }

            return new ErrorResultModel<FaqModel>("El registro que intenta obtener no existe");
        }

        public ResultModel<FaqModel> AddRating(Guid id)
        {

            var entity = QueryableBase.SingleOrDefault(e => e.Id == id);

            entity.Rating += 1;

            var model = Mapper.Map<FaqModel>(entity);

            DataContext.SaveChanges();

            var operationResult = new SuccessResultModel<FaqModel>(model);

            return operationResult;
        }
    }
}
