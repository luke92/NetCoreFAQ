﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Net.Http;
using System.Reflection.Metadata;
using System.Reflection.Metadata.Ecma335;
using System.Security.Claims;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using AutoMapper.Configuration;
using HUA.Core.Helpers;
using HUA.Core.Models;
using HUA.Core.Modules;
using HUA.Core.Settings;
using HUA.EstructuraHospitalaria.Business;
using HUA.FAQ.Business.Modules.Authentication.Models;
using HUA.FAQ.Data;
using HUA.FAQ.Data.Entities;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Newtonsoft.Json.Linq;

namespace HUA.FAQ.Business.Modules.Authentication
{
    public class AuthenticationModule : BaseModule<FAQContext>
    {
        private readonly Microsoft.Extensions.Configuration.IConfiguration _configuration;
        private readonly SecuritySettings _securitySettings;
        private readonly ISeguridadService _seguridadService;

        public AuthenticationModule(FAQContext dataContext, 
        Microsoft.Extensions.Configuration.IConfiguration configuration,
        IOptions<SecuritySettings> securitySettings,
        ISeguridadService seguridadService) : base(dataContext)
        {
            _configuration = configuration;
            _securitySettings = securitySettings.Value;
            _seguridadService = seguridadService;
        }

        public async Task<ResultModel<AuthenticationResultModel>> Authenticate(AuthenticationModel model)
        {

            ResultModel<AuthenticationResultModel> result;

            // Seteamos el código de la aplicación
            model.CodigoAplicacion = _securitySettings.Codigo;

            ResultModel<AuthenticationResultModel> apiResponse =
                await _seguridadService.securityAuthenticationAsync(_configuration["Security:AuthenticateUri"], model);

            // ¿La autenticación fue correcta?
            if (apiResponse.Result == OperationResult.Ok)
            {
                // Extraemos el token
                IEnumerable<Claim> claims = new JwtSecurityToken(apiResponse.Data.Token).Claims;

                // Generamos la respuesta
                result = new SuccessResultModel<AuthenticationResultModel>(new AuthenticationResultModel()
                {
                    Id = new Guid(claims.FirstOrDefault(x => x.Type == ClaimTypes.Sid).Value),
                    Nombre = claims.FirstOrDefault(x => x.Type == ClaimTypes.GivenName).Value,
                    Apellido = claims.FirstOrDefault(x => x.Type == ClaimTypes.Surname).Value,
                    Correo = claims.FirstOrDefault(x => x.Type == ClaimTypes.Email).Value,
                    ActiveDirectoryUserName = claims.FirstOrDefault(x => x.Type == ClaimTypes.WindowsAccountName).Value,
                    Perfiles = claims.Where(x => x.Type == ClaimTypes.Role).Select(x => x.Value).ToArray<string>()
                });
            }
            else
            {
                result = apiResponse;
            }

            return result;
        }
    }
}
