﻿using System;

namespace HUA.FAQ.Business.Modules.Authentication.Models
{
    public class AuthenticationModel
    {
        public Guid TipoDeDocumentoId { get; set; }
        public string NumeroDeDocumento { get; set; }
        public string Password { get; set; }

        public string CodigoAplicacion { get; set; }
    }
}
