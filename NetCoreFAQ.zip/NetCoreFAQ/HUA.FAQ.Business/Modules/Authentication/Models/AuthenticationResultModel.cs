﻿using System;
using System.Collections.Generic;

namespace HUA.FAQ.Business.Modules.Authentication.Models
{
    public class AuthenticationResultModel
    {
        public Guid Id { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Correo { get; set; }
        public string ActiveDirectoryUserName { get; set; }
        public string SesionId { get; set; }
        public string Token { get; set; }
        public string[] Perfiles { get; set; }
        public string Avatar { get; set; }
    }
}
