﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HUA.Core.Models;
using HUA.Core.Modules;
using HUA.FAQ.Business.Modules.Tag.Models;
using HUA.FAQ.Data;




namespace HUA.FAQ.Business.Modules.Tag
{
    //public class CategoryModule : CrudModule<FAQContext, Data.Entities.Category, CategoryModel>
    public class TagModule : CrudModule<FAQContext, Data.Entities.Tag, TagModel>
    {
        public TagModule(FAQContext context) : base(context)
        {
            /*
             * Dicha propiedad hay que asignarla debido a que la clase abstracta "padre"
             * la emplea para realizar las consultas que constituyen el CRUD
             */
            QueryableBase = context.Set<Data.Entities.Tag>().AsQueryable();
        }

        protected override IEnumerable<ErrorModel> CheckCreateValidations(TagModel model)
        {
            if (string.IsNullOrWhiteSpace(model.Name) || model.Name.Length < 3)
                yield return new ErrorModel("Name", "El nombre es requerido y debe tener al menos 3 caracteres");

        
            var existTag = DataContext.Tags.FirstOrDefault(x => x.Name == model.Name);

            if (existTag != null)
                yield return new ErrorModel("Name", "El nombre ya existe");
        }

        protected override IEnumerable<ErrorModel> CheckDeleteValidations(Guid model)
        {   /*
            var tagInUse = DataContext.FaqTags.Any(x => x.Tag.Id == model);

            if (tagInUse)
                yield return new ErrorModel("Name", "El Tag no puede eliminarse por que está en uso");
                */
            return new List<ErrorModel>();
        }

        protected override IEnumerable<ErrorModel> CheckUpdateValidations(TagModel model)
        {
            return CheckCreateValidations(model);
        }
    }
}
