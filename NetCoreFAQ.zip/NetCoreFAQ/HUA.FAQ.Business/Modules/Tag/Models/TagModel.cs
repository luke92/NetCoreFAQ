﻿using System;
using System.Collections.Generic;
using System.Text;
using HUA.Core.Entities;
using HUA.Core.Models;

namespace HUA.FAQ.Business.Modules.Tag.Models
{
    public class TagModel : GenericModel
    {
        public string Name { get; set; }
    }
}
