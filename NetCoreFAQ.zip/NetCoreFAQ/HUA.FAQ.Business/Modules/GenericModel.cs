﻿using System;
using System.Collections.Generic;
using System.Text;
using HUA.Core.Models;

namespace HUA.FAQ.Business.Modules
{
    public abstract class GenericModel : IEntityModel
    {
        public Guid Id { get; set; }
        public string CreatedUser { get; set; }
        public string UpdateUser { get; set; }
    }
}
