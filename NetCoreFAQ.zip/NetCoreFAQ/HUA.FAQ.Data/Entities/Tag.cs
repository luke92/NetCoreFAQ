﻿using System;
using System.Collections.Generic;
using System.Text;
using HUA.Core.Entities;

namespace HUA.FAQ.Data.Entities
{
    public class Tag : Entity
    {
        public string Name { get; set; }
        public virtual ICollection<FAQTag> FaqTags { get; set; }
    }
}
