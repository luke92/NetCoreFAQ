﻿using System;
using System.Collections.Generic;
using System.Text;
using HUA.Core.Entities;

namespace HUA.FAQ.Data.Entities
{
    public abstract class Entity : HUAEntity
    {
        

    }
}
