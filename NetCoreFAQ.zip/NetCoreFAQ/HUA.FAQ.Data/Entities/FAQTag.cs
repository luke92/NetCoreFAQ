﻿using System;
using System.Collections.Generic;
using System.Text;

namespace HUA.FAQ.Data.Entities
{
    public class FAQTag
    {
        public Guid FAQId { get; set; }
        public virtual FAQ FAQ { get; set; }
        public Guid TagId { get; set; }
        public virtual Tag Tag { get; set; }
    }
}
