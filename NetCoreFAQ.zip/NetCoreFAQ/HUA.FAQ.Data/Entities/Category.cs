﻿using System;
using System.Collections.Generic;
using System.Text;
using HUA.Core.Entities;

namespace HUA.FAQ.Data.Entities
{
    public class Category : Entity
    {
        public string Name { get; set; }
        public virtual ICollection<FAQ> faqs { get; set; }
    }
}
