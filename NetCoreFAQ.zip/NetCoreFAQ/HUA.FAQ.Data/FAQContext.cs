﻿using HUA.FAQ.Data.Entities;
using Microsoft.EntityFrameworkCore;

namespace HUA.FAQ.Data
{
    public class FAQContext : DbContext
    {
        public FAQContext(DbContextOptions<FAQContext> options) 
            : base(options)
        { }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Entities.FAQ>().ToTable("FAQS", "FAQ");
            modelBuilder.Entity<Category>().ToTable("Categories", "FAQ");
            modelBuilder.Entity<Tag>().ToTable("Tags", "FAQ");
            modelBuilder.Entity<FAQTag>().ToTable("FaqTag", "FAQ");

            // Definimos las PK
            modelBuilder.Entity<FAQTag>()
                .HasKey(x => new { x.FAQId, x.TagId });

            // Definimos la relación FAQTAG <-> FAQ
            modelBuilder.Entity<FAQTag>()
                .HasOne(f => f.FAQ)
                .WithMany(ft => ft.FaqTags)
                .HasForeignKey(f => f.FAQId);

            // Definimos la relación FAQTAG <-> TAG
            modelBuilder.Entity<FAQTag>()
                .HasOne(t => t.Tag)
                .WithMany(ft => ft.FaqTags)
                .HasForeignKey(t => t.TagId);
        }

        public DbSet<Entities.FAQ> FAQs { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Tag> Tags { get; set; }
        public DbSet<FAQTag> FaqTags { get; set; }
    }
}
