﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HUA.Core.Models;
using HUA.FAQ.Business.Modules.Faq;
using HUA.FAQ.Business.Modules.Faq.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace HUA.FAQ.Web.Server.Controllers
{
    ///
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class FaqRatingController : ControllerBase
    {
        private readonly FaqModule _module;

        /// <inheritdoc />
        public FaqRatingController(FaqModule module)
        {
            _module = module;
        }
        ///
        [HttpGet("{id}")]
        [AllowAnonymous]
        public IActionResult Get(Guid id)
        {
            ResultModel<FaqModel> operationResult = _module.AddRating(id);

            if (operationResult == null)
                return NotFound();

            return Ok(operationResult);
        }
    }
}
