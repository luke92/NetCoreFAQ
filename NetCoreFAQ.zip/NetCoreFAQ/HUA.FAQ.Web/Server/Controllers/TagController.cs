﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HUA.Core.Models;
using HUA.FAQ.Business.Modules.Tag;
using HUA.FAQ.Business.Modules.Tag.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HUA.FAQ.Web.Server.Controllers
{
    ///
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class TagController : ControllerBase
    {
        private readonly TagModule _module;
        ///
        public TagController(TagModule module)
        {
            _module = module;
        }
        ///
        [HttpGet]
        [AllowAnonymous]
        public IActionResult Get([FromQuery]IDictionary<string, string> queryString)
        {
            var operationResult = _module.GetPage(queryString);

            if (operationResult.Result != OperationResult.Ok)
                return BadRequest(operationResult);

            return Ok(operationResult);
        }
        ///
        [HttpGet("{id}")]
        [AllowAnonymous]
        public IActionResult Get(Guid id)
        {
            var requestedItem = _module.GetItem(id);

            if (requestedItem == null)
                return NotFound();

            return Ok(requestedItem);
        }
        ///
        [HttpPut]
        [HttpPost]
        public IActionResult Post([FromBody] TagModel model)
        {
            model.CreatedUser = this.User.Identity.Name;

            var operationResult = _module.Create(model);

            if (operationResult.Result != OperationResult.Ok)
                return StatusCode(422, operationResult);

            return Ok(model);
        }
        ///
        [HttpPut("{id}")]
        public IActionResult Put(Guid id, [FromBody] TagModel model)
        {
            model.UpdateUser = this.User.Identity.Name;

            var operationResult = _module.Update(id, model);

            if (operationResult.Result != OperationResult.Ok)
                return StatusCode(422, operationResult);

            return Ok(model);
        }
        ///
        [HttpDelete("{id}")]
        public IActionResult Delete(Guid id)
        {
            var operationResult = _module.Delete(id);

            if (operationResult.Result != OperationResult.Ok)
                return StatusCode(422, operationResult);

            return Ok(id);
        }
    }
}