﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using HUA.Core.Models;
using HUA.FAQ.Business.Modules.Authentication;
using HUA.FAQ.Business.Modules.Authentication.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.Security.Cryptography;
using Microsoft.Extensions.Configuration;

namespace HUA.FAQ.Web.Server.Controllers
{
    ///
    [Route("api/v1/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly AuthenticationModule _module;
        private readonly IConfiguration _configuration;

        ///
        public AuthenticationController(AuthenticationModule module, 
        IConfiguration configuration)
        {
            _module = module;
            _configuration = configuration;
        }

        ///
        [HttpPost]
        public async System.Threading.Tasks.Task<IActionResult> AuthenticateAsync([FromBody] AuthenticationModel model)
        {
            // try to authenticate the user

            // Apply UpperCase
            var operationResult = await _module.Authenticate(model);

            // if supplied data was incorrect, return errors
            if (operationResult.Result != OperationResult.Ok)
                return StatusCode(422, operationResult);

            // if not, construct user claims information
            var user = operationResult.Data;
            var userClaims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, user.Nombre ?? string.Empty)
            };

            foreach (string rol in user.Perfiles) {
              userClaims.Add(new Claim(ClaimTypes.Role, rol));
            }

            // add user and encryption information to token
            var token = new JwtSecurityToken(
                issuer: _configuration["JWT:Issuer"],
                audience: _configuration["JWT:Audience"],
                expires: DateTime.UtcNow.AddMinutes(Int32.Parse(_configuration["JWT:TimeLife"])),
                signingCredentials: new SigningCredentials(
                    new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JWT:Secret"])), 
                    SecurityAlgorithms.HmacSha256),
                claims: userClaims
            );

            // return secyrity token to client
            var result = new AuthenticationResultModel
            {
                Token   = new JwtSecurityTokenHandler().WriteToken(token),
                Nombre  = user.Nombre ?? string.Empty,
                Avatar  = getAvatar(user.Nombre)
            };

            return Ok(result);
        }

        private string getAvatar(string UserName){
            //  Compute the hash
            string hash = HashEmailForGravatar(builEmail(UserName));
            //  Assemble the url and return
            return string.Format("{0}{1}", _configuration["Gravatar:Url"] , hash);
        }

        private string builEmail(string UserName){
            return string.Format("{0}@{1}", UserName, _configuration["Email:Dominio"]);
        }

        /// Hashes an email with MD5.  Suitable for use with Gravatar profile
        /// image urls
        private static string HashEmailForGravatar(string email)
        {
            // Create a new instance of the MD5CryptoServiceProvider object.  
            MD5 md5Hasher = MD5.Create();

            // Convert the input string to a byte array and compute the hash.  
            byte[] data = md5Hasher.ComputeHash(Encoding.Default.GetBytes(email));

            // Create a new Stringbuilder to collect the bytes  
            // and create a string.  
            StringBuilder sBuilder = new StringBuilder();

            // Loop through each byte of the hashed data  
            // and format each one as a hexadecimal string.  
            for(int i = 0; i < data.Length; i++)
            {
                sBuilder.Append(data[i].ToString("x2"));
            }

            return sBuilder.ToString();  // Return the hexadecimal string. 
        }
    }
}