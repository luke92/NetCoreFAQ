﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HUA.Core.Models;
using HUA.FAQ.Business.Modules.Faq;
using HUA.FAQ.Business.Modules.Faq.Models;
using HUA.FAQ.Web.Server.Filters;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authentication.JwtBearer;

namespace HUA.FAQ.Web.Server.Controllers
{
    ///
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class FaqController : ControllerBase
    {
        private readonly FaqModule _module;

        ///
        public FaqController(FaqModule module)
        {
            _module = module;
        }

        ///
        [HttpGet]
        [AllowAnonymous]
        public async Task<IActionResult> GetAsync([FromQuery]IDictionary<string, string> queryString)
        {

            var operationResult = await AsyncGet(queryString);
           

            if (operationResult.Result != OperationResult.Ok)
                return BadRequest(operationResult);

            return Ok(operationResult);
        }

        ///
        [HttpGet("{id}")]
        [AllowAnonymous]
        public IActionResult Get(string id)
        {
            var operationResult = _module.AddVisit(id);

            if (operationResult.Result != OperationResult.Ok)
                return StatusCode(422, operationResult);

            return Ok(operationResult);
        }

        ///
        [HttpPut]
        [HttpPost]
        [Permission(Rol = "FAQ.Administrador")]
        public IActionResult Post([FromBody] FaqModel model)
        {
            model.CreatedUser = this.User.Identity.Name;

            var operationResult = _module.Create(model);

            if (operationResult.Result != OperationResult.Ok)
                return StatusCode(422, operationResult);

            return Ok(model);
        }
        ///
        [HttpPut("{id}")]
        [Authorize]
        [Permission(Rol = "FAQ.Administrador")]
        public IActionResult Put(Guid id, [FromBody] FaqModel model)
        {

            model.UpdateUser = this.User.Identity.Name;

            var operationResult = _module.Update(id, model);

            if (operationResult.Result != OperationResult.Ok)
                return StatusCode(422, operationResult);

            return Ok(model);
        }
        ///
        [HttpDelete("{id}")]
        [Authorize]
        [Permission(Rol = "FAQ.Administrador")]
        public IActionResult Delete(Guid id)
        {
            var operationResult = _module.Delete(id);

            if (operationResult.Result != OperationResult.Ok)
                return StatusCode(422, operationResult);

            return Ok(id);
        }


        private async Task<ResultModel<ListModel<FaqModel>>> AsyncGet(IDictionary<string, string> queryString)
        {

            var result = await Task.Run( () => _module.GetPage(queryString));
            return result;


        }
    }
}