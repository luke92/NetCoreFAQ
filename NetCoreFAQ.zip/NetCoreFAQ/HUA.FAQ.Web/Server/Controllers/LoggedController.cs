using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HUA.Core.Models;
using HUA.FAQ.Business.Modules.Tag;
using HUA.FAQ.Business.Modules.Tag.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HUA.FAQ.Web.Server.Controllers
{
    ///
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    [AllowAnonymous]
    public class LoggedController : ControllerBase
    {
        private readonly TagModule _module;
        ///
        public LoggedController(TagModule module)
        {
            _module = module;
        }
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpPut]
        [HttpPost]
        public IActionResult Post()
        {
            return Ok(new Object());
        }
        
    }
}