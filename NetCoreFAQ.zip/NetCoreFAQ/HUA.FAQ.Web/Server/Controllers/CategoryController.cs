﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using HUA.Core.Models;
using HUA.FAQ.Business.Modules.Category;
using HUA.FAQ.Business.Modules.Category.Models;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authorization;

namespace HUA.FAQ.Web.Server.Controllers
{
    ///
    [Route("api/v1/[controller]")]
    [ApiController]
    [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
    public class CategoryController : ControllerBase
    {
        private readonly CategoryModule _module;

        /// <summary>
        /// Category Module
        /// </summary>
        public CategoryController(CategoryModule module)
        {
            _module = module;
        }

        /// <summary>
        /// Category list
        /// </summary>
   
        [HttpGet]
        [AllowAnonymous]
        public IActionResult Get([FromQuery]IDictionary<string, string> queryString)
        {
            var user = User.Identity;

            var operationResult = _module.GetPage(queryString);

            if (operationResult.Result != OperationResult.Ok)
                return BadRequest(operationResult);

            return Ok(operationResult);
        }

         /// <summary>
        /// Category by <see cref="Guid"/>
        /// </summary>
        /// <param name="id">Unique id (Guid)</param>
        [HttpGet("{id}")]
        [AllowAnonymous]
        public IActionResult Get(Guid id)
        {
            var requestedItem = _module.GetItem(id);

            if (requestedItem == null)
                return NotFound();

            return Ok(requestedItem);
        }
        ///
        [HttpPut]
        [HttpPost]
        public IActionResult Post([FromBody] CategoryModel model)
        {

            model.CreatedUser = this.User.Identity.Name;

            var user = User.Identity;

            var operationResult = _module.Create(model);

            if (operationResult.Result != OperationResult.Ok)
                return StatusCode(422, operationResult);

            return Ok(model);
        }

        ///
        [HttpPut("{id}")]
        public IActionResult Put(Guid id, [FromBody] CategoryModel model)
        {
            model.UpdateUser = this.User.Identity.Name;

            var operationResult = _module.Update(id, model);

            if (operationResult.Result != OperationResult.Ok)
                return StatusCode(422, operationResult);

            return Ok(model);
        }

        ///
        [HttpDelete("{id}")]
        public IActionResult Delete(Guid id)
        { 
            var operationResult = _module.Delete(id);

            if (operationResult.Result != OperationResult.Ok)
                return StatusCode(422, operationResult);

            return Ok(id);
        }
    }
}