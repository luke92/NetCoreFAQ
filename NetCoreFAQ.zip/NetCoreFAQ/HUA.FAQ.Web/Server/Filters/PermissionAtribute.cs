﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Routing;

namespace HUA.FAQ.Web.Server.Filters
{
    /// <inheritdoc />
    /// <summary>
    /// </summary>
    public class PermissionAttribute : Attribute, IAuthorizationFilter
    {
        /// <summary>
        /// 
        /// </summary>
        public String Rol { get; set; }
        /// <inheritdoc />
        /// <summary>
        /// </summary>
        /// <param name="context"></param>
        public void OnAuthorization(AuthorizationFilterContext context)
        {
            List<String> roles = context.HttpContext.User.Claims
                .Where(x => x.Type == ClaimTypes.Role)
                .Select(x => x.Value).ToList<String>();

            if (!roles.Contains(this.Rol))
            {
                context.Result = new JsonResult(new { HttpStatusCode.Unauthorized });
            }
        }
    }
}
