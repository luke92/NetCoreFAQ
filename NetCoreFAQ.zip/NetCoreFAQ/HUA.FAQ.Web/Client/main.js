﻿import React from 'react';
import { render } from 'react-dom';
import { Provider, connect } from 'react-redux';
import { MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';

import Constants from './constants';
import store from './store';
import MainLayout from './pages/layout/mainLayout';


if (module.hot && process.env.NODE_ENV == 'development') {
    module.hot.accept();
}

// if local storage has an auth token, lets validate it and re login user
if (localStorage.authToken) {
    store.dispatch({ type: Constants.ActionTypes.LOGIN_AUTO, payload: { Token: localStorage.authToken} });
}

const theme = createMuiTheme({

    palette: {
        primary: {
            light: '#ffffff',
            main: '#6E9EC3',
            contrastText: '#fff',
        },
        secondary: {
            light: '#9D9C9B',
            main: '#2196f3',
            dark: '#2F3439',
            contrastText: '#fff',
        }
    }
});

// render application
render(<Provider store={store}>
    <MuiThemeProvider theme={theme}>
        <MainLayout />
    </MuiThemeProvider>
</Provider>, document.getElementById('app'));

