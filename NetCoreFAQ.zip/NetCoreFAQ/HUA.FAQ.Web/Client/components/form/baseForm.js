﻿import React from 'react';

class BaseForm extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            formData: props.formData
        };
    }

    handleChange = event => {
        const { formData } = this.state;
        formData[event.target.name] = event.target.value;
        this.setState({ formData });
    }

    handleCheckChange = name => event => {
        const { formData } = this.state;
        formData[name] = event.target.checked;
        this.setState(formData);
    }

    handleKeyPress = event => {
        if (event.key === 'Enter') {
            event.preventDefault();
            this.onSave();
        }
    }

    onSave = () => {
        this.props.saveHandler(this.state.formData);
    }

    onCancel = () => {
        this.props.cancelHandler();
    }
}

export default BaseForm;