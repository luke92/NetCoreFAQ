﻿import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import DialogTitle from '@material-ui/core/DialogTitle';

const styles = theme => ({
});

class HuaConfirmDialog extends React.Component {
    state = {
        open: false,
    };

    render() {
        const {
            open,
            title,
            body,
            closeHandler,
            yesHandler,
            noHandler
        } = this.props;

        return (
            <div>
                <Dialog
                    open={open}
                    onClose={closeHandler}
                    aria-labelledby="alert-dialog-title"
                    aria-describedby="alert-dialog-description">
                    <DialogTitle id="alert-dialog-title">{title}</DialogTitle>
                    <DialogContent>
                        <DialogContentText id="alert-dialog-description">
                            {body}
                        </DialogContentText>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={yesHandler} color="primary">
                            Si
                        </Button>
                        <Button onClick={noHandler} color="primary" autoFocus>
                            No
                        </Button>
                    </DialogActions>
                </Dialog>
            </div>
        );
    }
}

HuaConfirmDialog.propTypes = {
    title: PropTypes.string.isRequired,
    body: PropTypes.string.isRequired,
    closeHandler: PropTypes.func.isRequired,
    yesHandler: PropTypes.func.isRequired,
    noHandler: PropTypes.func.isRequired
}

export default withStyles(styles)(HuaConfirmDialog);