﻿import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import FormControl from '@material-ui/core/FormControl';
import Select from '@material-ui/core/Select';
import CategoryActions from '../../actions/CategoryActions';

import { connect } from 'react-redux';

import { setTimeout } from 'core-js';
import { error } from 'util';

const styles = theme => ({
    root: {
        display: 'flex',
        flexWrap: 'wrap',
    },
    formControl: {
        margin: theme.spacing.unit,
        minWidth: 120,
    },
    selectEmpty: {
        marginTop: theme.spacing.unit * 2,
    },
});

class SimpleSelectCategory extends React.Component {

    state = {
        Category: '',
        name: 'hai',
        Categories: []
    };

    handleChangeCategory = event => {
        let Category = event.target.value;
        this.setState({ Category });
        this.props.onChangeCategory(Category);
    };

    componentDidMount() {
        this.fetchListCategories(1, 100);
    }

    fetchListCategories = (page, pageSize, filter, orderBy) => {
        this.props.fetchCategories(page, pageSize, filter, orderBy)
            .then(result => {
                this.setState({ Categories: Array.from(result.Data.Items) });
            });
    }

    render() {
        const { classes } = this.props;
        const { Categories } = this.state;
        const menuItems = Categories.map((item, index) =>
            <MenuItem
                key={index}
                value={item.Id}>
                <em>{item.Name}</em>
            </MenuItem>
        );
        return (
            <FormControl className={classes.formControl} >
                <InputLabel htmlFor="category-simple">Categoría</InputLabel>
                <Select
                    value={this.props.selectedValue.Id || this.state.Category}
                    onChange={this.handleChangeCategory}
                    inputProps={{
                        Name: 'Category',
                        Id: 'category-simple',
                    }}
                >
                    <MenuItem value="" disabled><em>Elija una categoría</em></MenuItem>
                    {menuItems}
                </Select>
            </FormControl>
        );
    }
}

SimpleSelectCategory.propTypes = {
    fetchCategories: PropTypes.func.isRequired,
    classes: PropTypes.object.isRequired
};

export default connect(
    state => {
        return {
            authentication: state.authentication
        };
    },
    {
        fetchCategories: CategoryActions.fetchPageAction
    }
)(withStyles(styles)(SimpleSelectCategory));