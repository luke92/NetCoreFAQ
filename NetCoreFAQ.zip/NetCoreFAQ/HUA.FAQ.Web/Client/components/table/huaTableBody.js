﻿import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import TableBody from '@material-ui/core/TableBody';
import HuaTableRow from './huaTableRow';

const styles = theme => ({
});

class HuaTableBody extends React.Component {
    render() {
        const {
            classes,
            structure,
            collection,
            editRowHandler,
            deleteRowHandler,
            selectRowHandler
        } = this.props;

        if (!collection.Items) {
            return null;
        }

        return <TableBody>
            {
                collection.Items.map((item, index) => {
                    return <HuaTableRow
                        key={index}
                        structure={structure}
                        rowData={item}
                        editRowHandler={editRowHandler}
                        deleteRowHandler={deleteRowHandler}
                        selectRowHandler={selectRowHandler}
                    />
                })
            }
        </TableBody>;
    }
}

HuaTableBody.propTypes = {
    classes: PropTypes.object.isRequired,
    structure: PropTypes.array.isRequired,
    collection: PropTypes.object.isRequired,
    editRowHandler: PropTypes.func.isRequired,
    deleteRowHandler: PropTypes.func.isRequired,
    selectRowHandler: PropTypes.func.isRequired
}

export default withStyles(styles)(HuaTableBody);

