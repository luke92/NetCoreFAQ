﻿import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import TableRow from '@material-ui/core/TableRow';
import TableCell from '@material-ui/core/TableCell';
import Button from '@material-ui/core/Button';
import IconButton from '@material-ui/core/IconButton';
import { Info, Edit, Delete, CheckBox, CheckBoxOutlineBlank } from '@material-ui/icons';
import { Link } from 'react-router-dom';

const styles = theme => ({
    button: {
        margin: theme.spacing.unit,
    },
});

class HuaTableRow extends React.Component {
    onSelectRow = row => {
        this.props.selectRowHandler(row);
    }

    onEditRow = row => {
        this.props.editRowHandler(row);
    }

    onDeleteRow = row => {
        this.props.deleteRowHandler(row);
    }

    render() {
        const {
            isSelected,
            structure,
            rowData,
            classes
        } = this.props;

        //<IconButton className={classes.button} aria-label="Select" onClick={() => { this.onSelectRow(rowData) }}>
        //    <CheckBoxOutlineBlank />
        //</IconButton>

        return <TableRow hover tabIndex={-1} selected={rowData.isSelected}>
            <TableCell padding="checkbox">
                <IconButton className={classes.button} aria-label="Edit" color="primary" onClick={() => { this.onEditRow(rowData) }}>
                    <Edit />
                </IconButton>
                {/*Se verifica si la categoria existe (Solo en FAQs) y de estarlo se habilita el View*/}
                {typeof (rowData.Category) != 'undefined' &&
                    <Link to={'/faq/' + rowData.Id}>
                        <IconButton className={classes.button} aria-label="Info"  >
                            <Info />
                        </IconButton>
                    </Link>
                }   
                <IconButton className={classes.button} aria-label="Delete" onClick={() => { this.onDeleteRow(rowData) }}>
                    <Delete />
                </IconButton>
            </TableCell>
            {structure.map(column => {
                return (
                    <TableCell
                        key={column.id}
                        numeric={column.numeric || false}
                        padding={column.disablePadding ? 'none' : 'default'}>
                        {rowData[column.id]}
                    </TableCell>
                );
            }, this)}
        </TableRow>;
    }
}

HuaTableRow.propTypes = {
    classes: PropTypes.object.isRequired,
    structure: PropTypes.array.isRequired,
    rowData: PropTypes.object.isRequired,
    editRowHandler: PropTypes.func.isRequired,
    deleteRowHandler: PropTypes.func.isRequired,
    selectRowHandler: PropTypes.func.isRequired
}

export default withStyles(styles)(HuaTableRow);