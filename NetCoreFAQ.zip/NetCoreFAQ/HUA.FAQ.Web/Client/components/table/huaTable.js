﻿import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';

import HuaTableHeader from './huaTableHeader';
import HuaTableBody from './huaTableBody';
import TablePagination from '@material-ui/core/TablePagination';

const styles = theme => ({
    table: {
        minWidth: 1020,
    },
    tableWrapper: {
        overflowX: 'auto',
    },
});

class HuaTable extends React.Component {
    render() {
        const {
            classes,
            structure,
            collection,
            changePageHandler,
            changeRowsPerPageHandler,
            changeSortHandler,
            editRowHandler,
            deleteRowHandler,
            selectRowHandler
        } = this.props;

        return <div>
            <div className={classes.tableWrapper}>
                <Table className={classes.table} aria-labelledby="tableTitle">
                    <HuaTableHeader
                        structure={structure}
                        collection={collection}
                        changeSortHandler={changeSortHandler}
                    />
                    <HuaTableBody
                        structure={structure}
                        collection={collection}
                        editRowHandler={editRowHandler}
                        deleteRowHandler={deleteRowHandler}
                        selectRowHandler={selectRowHandler}
                    />
                </Table>
            </div>

            {collection.Count &&
                <TablePagination
                    component="div"
                    count={collection.Count || 0}
                    rowsPerPage={collection.PageSize}
                    page={collection.Page - 1}
                    labelRowsPerPage='Registros por Página'
                    backIconButtonProps={{ 'aria-label': 'Previous Page', }}
                    nextIconButtonProps={{ 'aria-label': 'Next Page', }}
                    onChangePage={changePageHandler}
                    onChangeRowsPerPage={changeRowsPerPageHandler}
                />
            }
        </div>;
    }
}

HuaTable.propTypes = {
    structure: PropTypes.array.isRequired,
    classes: PropTypes.object.isRequired,
    collection: PropTypes.object.isRequired,
    changePageHandler: PropTypes.func.isRequired,
    changeRowsPerPageHandler: PropTypes.func.isRequired,
    changeSortHandler: PropTypes.func.isRequired,
    editRowHandler: PropTypes.func.isRequired,
    deleteRowHandler: PropTypes.func.isRequired,
    selectRowHandler: PropTypes.func.isRequired
}

export default withStyles(styles)(HuaTable);