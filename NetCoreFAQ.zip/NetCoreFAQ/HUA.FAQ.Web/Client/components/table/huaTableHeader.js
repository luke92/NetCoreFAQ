﻿import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import TableHead from '@material-ui/core/TableHead';
import TableRow from '@material-ui/core/TableRow';
import TableCell from '@material-ui/core/TableCell';
import Checkbox from '@material-ui/core/Checkbox';
import Tooltip from '@material-ui/core/Tooltip';
import TableSortLabel from '@material-ui/core/TableSortLabel';

const styles = theme => ({
});

class HuaTableHeader extends React.Component {

    onChangeSort = property => event => {
        this.props.changeSortHandler(event, property);
    };

    render() {
        const { structure, collection } = this.props;

        let orderBy = ( collection.orderBy !== undefined )? collection.orderBy[0] : { key: 'Id', value: '-'};
        let order = orderBy.value == '-' ? 'desc' : 'asc';
        return <TableHead>
            <TableRow>
                <TableCell padding="checkbox">
                </TableCell>
                {structure.map(column => {
                    return (
                        <TableCell
                            key={column.id}
                            numeric={column.numeric}
                            padding={column.disablePadding ? 'none' : 'default'}
                            sortDirection={orderBy.key === column.id ? order : false}>
                            <Tooltip
                                title="Ordenar"
                                placement={column.numeric ? 'bottom-end' : 'bottom-start'}
                                enterDelay={300}>
                                <TableSortLabel
                                    active={orderBy.key.startsWith(column.id)}
                                    direction={order}
                                    onClick={this.onChangeSort(column.id)}
                                >
                                    {column.label}
                                </TableSortLabel>
                            </Tooltip>
                        </TableCell>
                    );
                }, this)}
            </TableRow>
        </TableHead>;
    }
}

HuaTableHeader.propTypes = {
    structure: PropTypes.array.isRequired,
    classes: PropTypes.object.isRequired,
    collection: PropTypes.object.isRequired,
    changeSortHandler: PropTypes.func.isRequired,
}

export default withStyles(styles)(HuaTableHeader);