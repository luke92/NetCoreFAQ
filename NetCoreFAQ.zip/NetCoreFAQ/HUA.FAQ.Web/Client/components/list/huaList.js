import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';

import { Grid, Typography, List, ListItem, ListItemText } from '@material-ui/core/';

import { Link } from 'react-router-dom';

const styles = theme => ({
    listContainer: {
        paddingLeft: 0,
    },
    listItem: {
        color: '#6c6b6a'
    },
    title: {
        color: '#2F3439',
        fontSize: 14,
        fontWeight: 500
    }
});

class HuaList extends React.Component {


    render() {

        const { classes, collection, title, link, showSize, propId } = this.props;
        let collectionSize = collection.length;
        let baseLink = link;
        return (
            <Grid item>
                <Typography variant="title" gutterBottom className={classes.title}>
                    {title} {showSize &&
                        <span>({collectionSize})</span>
                    }
                </Typography>
                {collection.length == 0 &&
                    <Typography variant="subheading" gutterBottom className={classes.subheading}>
                        No hay relacionados
                    </Typography>
                }
                <Grid>
                    <List>
                        {
                            collection.map((value, index) => {
                                let fullLink = "#";
                                let propiedadDiscriminador = propId;
                                if (baseLink != undefined) {
                                    if (propiedadDiscriminador == undefined) {
                                        propiedadDiscriminador = "Id";
                                    }
                                    fullLink = baseLink + value[propiedadDiscriminador];
                                }

                                return <ListItem
                                    className={classes.listContainer}
                                    key={index}
                                    role={undefined}
                                    dense
                                    button
                                    component={Link} to={fullLink}>
                                    <ListItemText disableTypography primary={<Typography className={classes.listItem}>{value.Name}</Typography>} />
                                </ListItem>
                            })
                        }
                    </List>
                </Grid>
            </Grid>
        );
    }
}

HuaList.propTypes = {
    collection: PropTypes.array.isRequired
}

export default withStyles(styles)(HuaList);