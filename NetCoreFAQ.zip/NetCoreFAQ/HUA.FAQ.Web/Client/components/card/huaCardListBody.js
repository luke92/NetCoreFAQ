import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';

import HuaCardListItem from './huaCardListItem';
import { Grid } from '../../../node_modules/@material-ui/core';

const styles = theme => ({
    root: {
        display: 'flex',
        justifyContent: 'center',

    },
    label: {
        fontSize: 20,
        color: 'blue'
    }
});

class HuaCardListBody extends React.Component {

    constructor() {
        super();

        this.renderLabel = this.renderLabel.bind(this);
    }

    renderLabel() {

        let { collection, classes } = this.props;

        if (collection.length == 0) {
            return
        }
    }

    render() {

        const { collection, classes } = this.props;

        if (!collection.Items) {
            return null;
        }

        return <div className={classes.root}>

            <Grid container>
                {

                    collection.Items.map((item, index) => {
                        return <Grid
                            Item direction="column"
                            justify="flex-start"
                            alignItems="center"
                            xs={12}
                            key={index}>
                            <HuaCardListItem
                                
                                title={item.Name}
                                body={item.Description}
                                avatar={item.Avatar}
                                user={item.CreatedUser}
                                date={item.CreatedDate}
                                rating={item.Rating}
                                visits={item.Visits}
                                link={'/faq/' + item.Id}
                            />
                        </Grid>
                    })
                }
            </Grid>

        </div>;
    }
}

HuaCardListBody.propTypes = {
    collection: PropTypes.object
};


export default withStyles(styles)(HuaCardListBody);