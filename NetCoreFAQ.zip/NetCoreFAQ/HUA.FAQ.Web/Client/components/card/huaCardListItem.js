import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Typography from '@material-ui/core/Typography';
import Avatar from '@material-ui/core/Avatar';
import Grid from '@material-ui/core/Grid';
import { StarBorder, RemoveRedEyeOutlined } from '@material-ui/icons';
import Chip from '@material-ui/core/Chip';

// Require Editor JS files.
import 'froala-editor/js/froala_editor.pkgd.min.js';

// Require Editor CSS files.
import 'froala-editor/css/froala_style.min.css';
import 'froala-editor/css/froala_editor.pkgd.min.css';

// Require Font Awesome.
import 'font-awesome/css/font-awesome.css';

// Moment
import Moment from 'react-moment';

import FroalaEditorView from 'react-froala-wysiwyg/FroalaEditorView';

const styles = theme => ({
    media: {
        height: 0,
        paddingTop: '56.25%', // 16:9
    },
    title: {
        color: '#6E9EC3',
        fontFamily: 'Roboto',
        fontSize: 20,
        fontWeight: 500,
        cursor: 'pointer',
        textOverflow: 'ellipsis',
        overflow: 'hidden',
        whiteSpace: 'nowrap',
    },
    body: {
        color: '#6c6b6a',
        fontFamily: 'Roboto',
        fontSize: 12,
        width: '100%'
    },
    avatar: {
        width: 35,
        height: 35,
    },
    name: {
        color: '#2A9FD8',
        fontFamily: 'Roboto',
        fontWeight: 500,
        fontSize: 12
    },
    date: {
        color: '#6c6b6a',
        fontFamily: 'Roboto',
        fontWeight: 500,
        fontSize: 12
    },
    avatar: {
        margin: 10,
        marginLeft: 0,
        cursor: 'pointer',
        backgroundColor: theme.palette.secondary.main,
        borderColor: 'solid 1px #CCD0D3'
    },
    icon: {
        fontSize: 20,
        marginLeft: 15,
        marginRight: 8
    },
    cardAction: {
        borderTop: 'solid 1px #CCD0D3',
        Color: '#6c6b6a'
    },
    card: {
        marginBottom: 15,
        marginTop: 15,
        border: 'solid 1px #CCD0D3'
    },
    cardWithOutBorder: {
        marginBottom: 15,
        marginTop: 15
    }
});

class HuaCardListItem extends React.Component {

    constructor() {
        super();

        this.state = {
            elevation: 5
        }
    }

    render() {

        const { classes,
            link,
            title,
            body,
            avatar,
            user,
            date,
            rating,
            visits,
            tags,
            withOutBorder } = this.props;

        let cardStyle = classes.card;

        let { elevation } = this.state;

        let firstLetter = "";
        if (!avatar && user) {
            firstLetter = user[0];
        }

        if (withOutBorder) {
            elevation = 0;
            cardStyle = classes.cardWithOutBorder;
        }

        return <div className={classes.body} >
            <Link to={link ? link : ''}>
                <Card className={cardStyle} elevation={elevation}>
                    <CardContent>
                        <Grid item container spacing={16}>
                            <Grid item xs={12}>
                                <Typography variant="headline" component="h2" className={classes.title}>
                                    {title}
                                </Typography>
                            </Grid>

                            <Grid item xs={12}>
                                <FroalaEditorView model={body} />
                            </Grid>

                            <Grid item container xs={12} spacing={16}>
                                {
                                    tags &&
                                    tags.map((item, index) => {
                                        return <Grid item key={index} >
                                            <Chip
                                                key={item.id}
                                                label={item.name} />
                                        </Grid>
                                    })
                                }
                            </Grid>

                        </Grid>
                    </CardContent>
                    <CardActions className={classes.cardAction}>
                        <Grid container direction="row" justify="space-between" alignItems="center">

                            <Grid item >
                                <Grid container direction="row" justify="flex-start" alignItems="center">
                                    <Grid item>
                                        <Avatar
                                            alt={user}
                                            src={avatar}
                                            className={classes.avatar}
                                        >{firstLetter}</Avatar>
                                    </Grid>

                                    <Grid item  >
                                        <Grid container direction='column' justify='center'>
                                            <Grid item>
                                                <label className={classes.name}>{user}</label>
                                            </Grid>

                                            <Grid item>
                                                <Moment className={classes.date} format="DD-MM-YYYY">
                                                    {date}
                                                </Moment>
                                            </Grid>
                                        </Grid>

                                    </Grid>
                                </Grid>

                            </Grid>

                            <Grid item >
                                <Grid container direction='row' justify='center'>
                                    <Grid item container direction='row' alignItems='center' justify="flex-end">
                                        <Grid item>
                                            <StarBorder className={classes.icon} />
                                        </Grid>
                                        <Grid item>
                                            <label className={classes.date}>{rating}</label>
                                        </Grid>
                                        <Grid item>
                                            <RemoveRedEyeOutlined className={classes.icon} />
                                        </Grid>
                                        <Grid item>
                                            <label className={classes.date}>{visits}</label>
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </Grid>

                        </Grid>

                    </CardActions>
                </Card>
            </Link>
        </div>;
    }
}

HuaCardListItem.propTypes = {
    title: PropTypes.string.isRequired,
    body: PropTypes.string.isRequired,
    user: PropTypes.string.isRequired,
    date: PropTypes.string.isRequired,
    visits: PropTypes.number.isRequired,
    rating: PropTypes.number.isRequired,
    classes: PropTypes.object.isRequired,
    tags: PropTypes.array
};

export default withStyles(styles)(HuaCardListItem);