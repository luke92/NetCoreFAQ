import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';

import HuaCardListBody from './huaCardListBody'
import { Typography, Grid } from '../../../node_modules/@material-ui/core';

import Pagination from 'rc-pagination';
import localeInfo from 'rc-pagination/lib/locale/es_ES';
require("rc-pagination/assets/index.css");

const styles = theme => ({
    BodyList : {
        marginTop: 10,
        marginLeft: 'auto',
        marginRight: 'auto',
        width: '100%',
        maxWidth: 750,
    }
});

class HuaCardList extends React.Component {


    render() {

        const { classes,
                collection, 
                itemStyle,
                handlePageChange } = this.props;

        return <div className={classes.BodyList}>
                <Grid container>
                    <Grid item xs={12}>
                        <Typography variant="body2" gutterBottom>
                        <b>{ collection.Count }</b> resultados encontrados
                        </Typography>
                    </Grid>
                </Grid>
                <HuaCardListBody
                    collection = { collection }
                />
                
                <Grid container justify="center">
                    <Pagination
                        total = { collection.Count}
                        current = { collection.Page }
                        onChange = { handlePageChange }
                        locale = { localeInfo }
                        pageSize = { collection.PageSize }
                    />
                </Grid>
            </div>;
    }
}

HuaCardList.propTypes = {
    collection: PropTypes.object
};
  

export default withStyles(styles)(HuaCardList);