/* eslint-disable react/prop-types */

import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';


class Permission extends React.Component {


    getUserPermissions() {
        if (this.props.authentication.role != undefined)
          return this.props.authentication.role;
        else
          return [];
    }
    
    hasPermission() {
        return this.getUserPermissions().indexOf(this.props.rol) !== -1
    }
    
    render() {
        if(this.hasPermission()){
            return <div>{ this.props.children }</div>
        }  else {
            return <div></div>
        }
     }
}

Permission.propTypes = {
    rol: PropTypes.string.isRequired,
};

export default connect(
    state => {
        return {
            authentication: state.authentication
        };
    },
    {
        
    }
)(Permission);