import React from 'react';
import PropTypes from 'prop-types';

import { withStyles } from '@material-ui/core/styles';
import { connect } from 'react-redux';
import {Grid, Typography, Link, Button } from '@material-ui/core/';
import HuaCardListItem from '../../components/card/huaCardListItem';
import CategoryActions from '../../actions/CategoryActions';
import FaqActions from '../../actions/faqActions';
import TagActions from '../../actions/tagActions';
import { showError, showSuccess } from '../../actions/messageActions';

import HuaList from '../../components/list/huaList'; 

const styles = theme => ({
    root: {
        width: '100%',
        maxWidth: 1140,
        marginLeft: 'auto',
        marginRight: 'auto',
        marginTop: 120,
    },
    paper: {
        padding: theme.spacing.unit * 2,
        textAlign: 'center',
        color: theme.palette.text.secondary,
    },
    header: {
        paddingRight: theme.spacing.unit,
    },
    textCenter: {
        textAlign: 'center'
    },
    button: {
        marginTop: 30
    },
    title: {
        flex: '0 0 auto',
    },
    separator: {
        marginTop:30,
        marginBottom: 30,
        borderTop: 'solid 1px #CCD0D3',
        maxWidth: 200,
        marginLeft: 0
    },
    rightSidebar : {
        paddingLeft: '50px!important'
    }
});

class HomePage extends React.Component {
    constructor() {
        super();

        this.state = {
            message: null,
            Errors: [],
            formData: null,
            collectionNewFaqs: [],
            collectionCategorías: [],
            collectionPopularFaqs: [],
            collectionNewTags: []

        }
    }

    componentDidMount() {
        this.fetchNewFaqs(1, 3, '', '-CreatedDate');
        this.fetchListCategorías(1, 10, "", "+Id");
        this.fetchPopularFaqs(1, 3, '', '-Visits');
        this.fetchNewTags(1, 10, '', '+Id');
    }

    fetchListCategorías = (page, pageSize, filter, orderBy) => {
        this.props.fetchCategories(page, pageSize, filter, orderBy)
            .then(result => {
                this.setState({ collectionCategorías: result.Data.Items });
            });
    }


    fetchPopularFaqs = (page, pageSize, filter, orderBy) => {
        this.props.fetchFaqs(page, pageSize, filter, orderBy)
            .then(result => {
                this.setState({ collectionPopularFaqs: Array.from(result.Data.Items) });
            });
    }

    fetchNewFaqs = (page, pageSize, filter, orderBy) => {
        this.props.fetchFaqs(page, pageSize, filter, orderBy)
            .then(result => {
                this.setState({ collectionNewFaqs: Array.from(result.Data.Items) });
            });
    }

    fetchNewTags = (page, pageSize, filter, orderBy) => {
        this.props.fetchTags(page, pageSize, filter, orderBy)
            .then(result => {
                this.setState({ collectionNewTags: Array.from(result.Data.Items) });
            });
    }

    render() {
        const { errors, collectionNewFaqs, collectionPopularFaqs, collectionCategorías, collectionNewTags } = this.state;
        const { classes } = this.props;

        return (<div className={classes.root}>
            <Grid container spacing={24}>
                <Grid item xs={12}>
                    <Typography variant="title" gutterBottom>
                        Nuevos artículos
                    </Typography>
                </Grid>
                <Grid item container xs={12} spacing={24}>
                    {
                        collectionNewFaqs.map((item, index) => {
                            return <Grid container item md={4} key={index}>
                                <HuaCardListItem
                                    title={item.Name}
                                    body={item.Description}
                                    avatar={item.Author}
                                    user={item.CreatedUser}
                                    date={item.CreatedDate}
                                    rating={item.Rating}
                                    visits={item.Visits}
                                    link = { '/faq/' + item.Id }
                                />
                            </Grid>
                        })
                    }
                </Grid>
                <Grid container item xs={12} md={8}>
                    <Typography variant="title" gutterBottom >
                        Artículos populares
                    </Typography>
                    {
                        collectionPopularFaqs.map((item, index) => {
                            return <Grid container item key={index} >
                                <HuaCardListItem
                                    title = { item.Name }
                                    body = { item.Description }
                                    avatar = { item.Author }
                                    user = { item.CreatedUser }
                                    date={item.CreatedDate}
                                    rating={item.Rating}
                                    visits = { item.Visits }
                                    link = { '/faq/' + item.Id }
                                />
                            </Grid>
                        })
                    }
                    <Grid item xs={12} className={classes.textCenter}>
                        <Button href="faq" variant="contained" color="primary" className={classes.button}>
                            Ver todos
                        </Button>
                    </Grid>
                </Grid>
                <Grid item xs={12} md={4} className={classes.rightSidebar}>
                    <HuaList collection={collectionCategorías} title="Categorías" link="/faq?CategoryId="></HuaList>
                    <hr className={classes.separator}/>
                    <HuaList collection={collectionNewTags} title="Tags" link="/faq?TagId="></HuaList>
                </Grid>
            </Grid>
        </div>
        );
    }
}

HomePage.propTypes = {
    classes: PropTypes.object.isRequired,
    fetchCategories: PropTypes.func.isRequired,
    fetchFaqs: PropTypes.func.isRequired,
    fetchTags: PropTypes.func.isRequired
}


export default connect(
    state => {
        return {
            authentication: state.authentication
        };
    },
    {
        fetchCategories: CategoryActions.fetchPageAction,
        fetchFaqs: FaqActions.fetchPageAction,
        fetchTags: TagActions.fetchPageAction,
        showError: showError,
        showSuccess: showSuccess
    }

)(withStyles(styles)(HomePage));

