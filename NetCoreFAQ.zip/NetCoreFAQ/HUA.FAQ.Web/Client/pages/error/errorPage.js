import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import { connect } from 'react-redux';
import { Grid } from '@material-ui/core';
import { Typography } from '@material-ui/core';

const styles = theme => ({
    root: {
        width: '100%',
        marginTop: 120,
        maxWidth: 1140,
        marginLeft: 'auto',
        marginRight: 'auto'
    }
});


class CategoryPublicPage extends React.Component {

    render() {
        const { classes } = this.props;

        return (
            <div className={classes.root}>
                <Grid container direction="column" justify="center" alignItems="center" spacing={24}>
                    <Grid item>
                        <Typography variant="display3" gutterBottom>
                            Error :(
                        </Typography>
                    </Grid>
                    <Grid item>
                        <Typography variant="subheading" gutterBottom>
                            Estamos trabajando para resolver el inconveniente.
                        </Typography>
                    </Grid>
                </Grid>
            </div>);
    }
}

/* CategoryPublicPage.propTypes = {
    fetchCategories: PropTypes.func.isRequired
}*/
export default connect(
    state => {
        return {
            authentication: state.authentication
        };
    },
    {
        // fetchCategories: CategoryActions.fetchPageAction
    }
)(withStyles(styles)(CategoryPublicPage));