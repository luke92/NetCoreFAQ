﻿import React from 'react';
import Header from './components/header';
import LoginPage from '../login/loginPage';

export default class PublicLayout extends React.Component {
    constructor() {
        super();
    }

    render() {
        return (
            <div>
                <LoginPage />
            </div>
        );
    };
};