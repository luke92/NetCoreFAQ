﻿import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { withStyles } from '@material-ui/core/styles';
import PrivateLayout from './privateLayout';
import Messager from '../../components/messager';
import { closeMessager } from '../../actions/messageActions';
import { BrowserRouter as Router } from 'react-router-dom';

import LoggedActions from '../../actions/LoggedActions';

const styles = theme => ({
    root: {
        flexGrow: 1,
    }
});

class MainLayout extends React.Component {

    componentDidCatch(error, errorInfo) {
        // You can also log the error to an error reporting service
        console.log(error);
        console.log(errorInfo);

        this.props.storeLogged({name: 'ReactJs', details: errorInfo});

        if ( process.env.NODE_ENV == 'production' ) {
            window.location.href = '/error';
        }
    }

    render() {
        const { classes, messager, closeMessager } = this.props;
        return <Router>
                    <div className={classes.root}>
                        <Messager
                            open={messager.open}
                            messages={messager.messages}
                            messageType={messager.type}
                            closeHandler={closeMessager}
                        />
                        {<PrivateLayout />}
                    </div>
                </Router>
    }
}

MainLayout.propTypes = {
    classes: PropTypes.object.isRequired,
    authentication: PropTypes.object.isRequired,
    storeLogged: PropTypes.func.isRequired
}

export default connect(
    state => {
        return {
            authentication: state.authentication,
            messager: state.messager
        }
    },
    {
        closeMessager: closeMessager,
        storeLogged: LoggedActions.createAction
    }
)(withStyles(styles)(MainLayout));