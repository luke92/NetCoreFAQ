﻿import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { BrowserRouter as Router, Switch, Route, Redirect, Link } from 'react-router-dom';
import { withRouter } from 'react-router';
import classNames from 'classnames';
import { withStyles } from '@material-ui/core/styles';
import Drawer from '@material-ui/core/Drawer';
import AppBar from '@material-ui/core/AppBar';
import FormControl from '@material-ui/core/FormControl';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Toolbar from '@material-ui/core/Toolbar';
import Avatar from '@material-ui/core/Avatar';
import Typography from '@material-ui/core/Typography';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import Button from '@material-ui/core/Button';
import ListItem from '@material-ui/core/ListItem';
import ListItemIcon from '@material-ui/core/ListItemIcon';
import ListItemText from '@material-ui/core/ListItemText';
import Grid from '@material-ui/core/Grid';
import FaqIcon from '@material-ui/icons/ContactSupportOutlined';
import LocalOfferIcon from '@material-ui/icons/LocalOfferOutlined';
import CategoryIcon from '@material-ui/icons/CategoryOutlined';
import ArrowDropDownIcon from '@material-ui/icons/ArrowDropDown';
import ExitToAppIcon from '@material-ui/icons/ExitToApp';
import AppsIcon from '@material-ui/icons/AppsOutlined';
import SearchBar from 'material-ui-search-bar'

import CategoryPage from '../category/categoryPage';
import LoginPage from '../login/loginPage';
import HomePage from '../home/homePage';
import FaqPage from '../faq/faqPage';
import TagPage from '../tag/tagPage';
import FaqPublicPage from '../faq/faqPublicPage';
import FaqViewPage from '../faq/faqViewPage';
import CategoryPublicPage from '../category/categoryPublicPage';
import ErrorPage from '../error/errorPage';
import Permission from '../../components/roles/permission'

import { logoutAction } from '../../actions/logoutAction';

import queryString from 'query-string';

const drawerWidth = 240;


const styles = theme => ({
    '@global': {
        body: {
            backgroundColor: '#F2F5F8'
        },
        '::placeholder': {
            color: '#000!important',
        },
        ':-ms-input-placeholder': {
            color: '#000!important',
        },
        '::-ms-input-placeholder': {
            color: '#000!important',
        },
        '*': {
            fontFamily: "'Roboto', sans-serif",
        },
        'a': {
            color: '#6E9EC3',
            fontWeight: 500,
        }
    },
    root: {
        minHeight: '100vh',
        flexGrow: 1,
        height: '80%',
        zIndex: 1,
        overflow: 'hidden',
        position: 'relative',
        display: 'flex',
    },
    appBar: {
        zIndex: theme.zIndex.drawer + 1,
        transition: theme.transitions.create(['width', 'margin'],
            {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.leavingScreen,
            }),
        backgroundColor: '#ffffff',
        color: '#7A7777',
    },
    appBarToolBar: {
        padding: 0
    },
    appBarShift: {
        marginLeft: drawerWidth,
        width: `100%`,
        transition: theme.transitions.create(['width', 'margin'],
            {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.enteringScreen,
            }),
    },
    menuButton: {
        marginLeft: 12,
        marginRight: 36,
    },
    hide: {
        display: 'none',
    },
    drawerPaper: {
        position: 'relative',
        whiteSpace: 'nowrap',
        width: drawerWidth,
        transition: theme.transitions.create('width',
            {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.enteringScreen,
            }),
    },
    drawerPaperClose: {
        overflowX: 'hidden',
        transition: theme.transitions.create('width',
            {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.leavingScreen,
            }),
        width: theme.spacing.unit * 7,
        [theme.breakpoints.up('sm')]: {
            width: theme.spacing.unit * 9,
        },
    },
    toolbar: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'flex-end',
        padding: '0 8px',
        ...theme.mixins.toolbar,
    },
    content: {
        flexGrow: 1,
        padding: theme.spacing.unit * 3,
    },
    flex: {
        flexGrow: 1,
    },
    logo: {
        maxHeight: 50,
    },
    logoutButton: {
        marginLeft: -12,
        marginRight: 20,
    },
    formSearchBar: {
        width: '100%'
    },
    avatar: {
        margin: 10,
        marginRight: -5,
        cursor: 'pointer',
        backgroundColor: theme.palette.secondary.main,
        borderColor: 'solid 1px #CCD0D3'
    },
    bootstrapFormLabel: {
        fontSize: 18,
    },
    toolBarSection: {
        borderBottom: 'solid 1px #D6D6D7'
    },
    toolBarSectionFirst: {
        height: 70,
        paddingLeft: 20,
        paddingRight: 20
    },
    toolBarSectionSecond: {
        height: 75,
    },
    tabRoot: {
        minWidth: 50,
        height: 74,
        '&:hover': {
            color: '#40a9ff',
            opacity: 1,
        },
        '&:focus': {
            color: '#40a9ff',
        },
    },

    loginButton: {
        color: 'white'
    },
    appIcon: {
        marginRight: 15,
        cursor: 'pointer',
    }

});

class PrivateLayout extends React.Component {


    constructor(props) {
        super(props);
        this.state = {
            open: false,
            urlSelected: 0,
            redirect: null,
            searchBox: queryString.parse(this.props.location.search).query,
            subDirectory: document.getElementsByTagName('base')[0].getAttribute("href")
        };
    }

    componentWillMount() {
        this.selectedTabUrl();
    }

    selectedTabUrl() {

        switch (window.location.pathname) {
            case '/home':
            case '/':
                this.setState({ urlSelected: 0 });
                break;
            case '/faq':
                this.setState({ urlSelected: 1 });
                break;
            case '/category':
                this.setState({ urlSelected: 2 });
                break;
            default:
                break;
        }
    }

    HandleOnRequestSearch = (text) => {
        this.setState({
            searchBox: text,
            redirect: '/faq?query=' + encodeURIComponent(text)
        });
    };

    handleChangeTabAppBar = (event, urlSelected) => {
        this.setState({ urlSelected });
    };

    toggleDrawer = (openStatus) => () => {
        this.setState({ open: openStatus });
    };

    render() {
        const { authentication, classes, theme, logoutAction } = this.props;
        const { urlSelected, redirect, searchBox } = this.state;

        let loginButton;
        let avatar;
        let appIcons;
        let imagenlogo;
        let arrowDropDownPerfil;

        if (this.props.authentication.isAuthenticated) {
            let firstLetter = "";
            if (this.props.authentication && this.props.authentication.name) {
                firstLetter = this.props.authentication.name[0];
            }
            appIcons = <AppsIcon className={classes.appIcon} onClick={this.toggleDrawer(true)} />
            avatar = <Avatar className={classNames(classes.avatar, "display-flex")} onClick={this.toggleDrawer(true)}>{firstLetter}</Avatar>;
            arrowDropDownPerfil = <ArrowDropDownIcon />;
            imagenlogo = <img style={{ cursor: 'pointer' }} src="static/images/header_logo.png" onClick={this.toggleDrawer(true)} className={classes.logo} />
        } else {
            loginButton = <Button component={Link} to="/login" variant="outlined" color="primary" className={classes.logoutButton}>Login</Button>;
            imagenlogo = <img src="static/images/header_logo.png" className={classes.logo} />
        }

        if (redirect) {

            this.setState({ redirect: null });

            return (
                <div>
                    <Router basename={this.state.subDirectory}>
                        <Redirect exact from='/' to={redirect} />
                    </Router>;
                </div>
            )
        }

        return (<Router basename={this.state.subDirectory}>
            <div className={classes.root}>
                <AppBar
                    position="absolute"
                    className={classNames(classes.appBar, this.state.open && classes.appBarShift, "appBar")}
                    elevation={0}
                >
                    <Toolbar className={classes.appBarToolBar}>
                        <Grid container direction="column" >
                            <Grid item container className={classNames(classes.toolBarSection, classes.toolBarSectionFirst)}>
                                <Grid item container xs direction="row"
                                    justify="flex-start"
                                    alignItems="center">
                                    {imagenlogo}
                                </Grid>
                                <Grid item container xs direction="row"
                                    justify="flex-end"
                                    alignItems="center" >
                                    <FormControl className={classes.formSearchBar}>
                                        <SearchBar
                                            onRequestSearch={this.HandleOnRequestSearch}
                                            placeholder="Necesito ayuda con ..."
                                            disableUnderline={true}
                                            value={searchBox}
                                            id="custom-css-input"
                                            style={{
                                                borderRadius: 3,
                                                backgroundColor: '#F7F8F9',
                                                border: '1px solid #D3D5D7',
                                                fontSize: 16,
                                                color: '#A8A6A6',
                                                boxShadow: 'none',
                                                padding: '0px 12px',
                                                width: 'calc(100% - 24px)',
                                                transition: theme.transitions.create(['border-color', 'box-shadow']),
                                                fontFamily: [
                                                    '-apple-system',
                                                    'BlinkMacSystemFont',
                                                    '"Segoe UI"',
                                                    'Roboto',
                                                    '"Helvetica Neue"',
                                                    'Arial',
                                                    'sans-serif',
                                                    '"Apple Color Emoji"',
                                                    '"Segoe UI Emoji"',
                                                    '"Segoe UI Symbol"',
                                                ].join(','),
                                                '&:focus': {
                                                    borderColor: '#80bdff',
                                                    boxShadow: '0 0 0 0.2rem rgba(0,123,255,.25)',
                                                },
                                            }}
                                        />
                                    </FormControl>
                                </Grid>
                                <Grid container item xs direction="row"
                                    justify="flex-end"
                                    alignItems="center">
                                    <Grid item container direction="row"
                                        justify="flex-end"
                                        alignItems="center">
                                        {appIcons}
                                        <Typography color="inherit" className={"display-flex"}>
                                            {this.props.authentication.name}
                                        </Typography>
                                        {avatar}
                                        {arrowDropDownPerfil}
                                        {loginButton}
                                    </Grid>
                                </Grid>
                            </Grid>
                            <Grid item container className={classNames(classes.toolBarSection, classes.toolBarSectionSecond)}>
                                <Grid item container xs
                                    container
                                    direction="row"
                                    justify="center"
                                    alignItems="center">
                                    <Tabs
                                        value={urlSelected} // TODO manejar cambio de rutas
                                        onChange={this.handleChangeTabAppBar}
                                        indicatorColor="primary"
                                        textColor="primary"
                                        centered>
                                        <Tab component={Link} to="/home" classes={{ root: classes.tabRoot }} label="Home" />
                                        <Tab component={Link} to="/faq" classes={{ root: classes.tabRoot }} label="FAQs" />
                                        <Tab component={Link} to="/category" classes={{ root: classes.tabRoot }} label="Categorías" />
                                    </Tabs>
                                </Grid>
                            </Grid>
                        </Grid>
                    </Toolbar>
                </AppBar>
                <Drawer open={this.state.open} onClose={this.toggleDrawer(false)}>
                    <div
                        tabIndex={0}
                        role="button"
                        onClick={this.toggleDrawer(false)}
                        onKeyDown={this.toggleDrawer(false)}
                    >
                        <div className={classes.toolbar}>
                            <IconButton onClick={this.toggleDrawer(false)}>
                                <CloseIcon />
                            </IconButton>
                        </div>

                        <Permission rol="FAQ.Administrador">
                            <Link to="/admin/faq">
                                <ListItem button >
                                    <ListItemIcon>
                                        <FaqIcon />
                                    </ListItemIcon>
                                    <ListItemText primary="FAQs" />
                                </ListItem>
                            </Link>
                            <Link to="/admin/category">
                                <ListItem button >
                                    <ListItemIcon>
                                        <CategoryIcon />
                                    </ListItemIcon>
                                    <ListItemText primary="Categorías" />
                                </ListItem>
                            </Link>
                            <Link to="/admin/tag">
                                <ListItem button >
                                    <ListItemIcon>
                                        <LocalOfferIcon />
                                    </ListItemIcon>
                                    <ListItemText primary="Tags" />
                                </ListItem>
                            </Link>           
                        </Permission>
                        
                        <Link to="/">
                            <ListItem button onClick={() => logoutAction()} >
                                <ListItemIcon>
                                    <ExitToAppIcon />
                                </ListItemIcon>
                                <ListItemText primary="Salir" />
                            </ListItem>
                        </Link>
                    </div>
                </Drawer>
                <main className={classes.content}>
                    <div className={classes.toolbar} />
                    <Switch>
                        <Route path="/home" exact={true} component={HomePage} />
                        <Route path="/category" exact={true} component={CategoryPublicPage} />
                        <Route path="/admin/category" exact={true} component={CategoryPage} />
                        <Route path="/admin/faq" exact={true} component={FaqPage} />
                        <Route path="/admin/tag" exact={true} component={TagPage} />
                        <Route path="/login" exact={true} component={LoginPage} />
                        <Route path="/faq/:Id" exact={true} component={FaqViewPage} />
                        <Route path="/faq" exact={true} component={FaqPublicPage} />
                        <Route path="/error" exact={true} component={ErrorPage} />
                        <Route path="/" exact={true} component={HomePage} />
                        <Redirect from='*' to='/' />
                    </Switch>
                </main>
            </div>
        </Router>
        );
    };
}

PrivateLayout.propTypes = {
    classes: PropTypes.object.isRequired,
    theme: PropTypes.object.isRequired,
    logoutAction: PropTypes.func.isRequired
};

export default connect(
    state => {
        return {
            authentication: state.authentication,
            searchBox: state.searchBox
        };
    }
    , {
        logoutAction
    })
    (
    withStyles(styles, { withTheme: true })(
        withRouter(PrivateLayout))
    );
