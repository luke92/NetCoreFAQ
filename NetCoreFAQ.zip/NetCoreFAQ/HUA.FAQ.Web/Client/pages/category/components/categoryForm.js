﻿import React from 'react';
import PropTypes from 'prop-types';
import BaseForm from '../../../components/form/baseForm';
import { withStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Typography from '@material-ui/core/Typography'
import Select from '@material-ui/core/Select';
import TextField from '@material-ui/core/TextField';
import FormControl from '@material-ui/core/FormControl';
import Switch from '@material-ui/core/Switch';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormHelperText from '@material-ui/core/FormHelperText';
import Grid from '@material-ui/core/Grid';

const styles = theme => ({
    form: {
        display: 'flex',
        flexWrap: 'wrap',
        padding: '20px'
    },
    textField: {
        marginLeft: theme.spacing.unit,
        marginRight: theme.spacing.unit,
        width: '100%'   
    },
    button: {
        margin: theme.spacing.unit,
    },
    input: {
        display: 'none',
    },
});

class CategoryForm extends BaseForm {

    render() {
        const {
            Id,
            Name,
        } = this.state.formData;
        const { classes, errors } = this.props;

        return <form noValidate autoComplete="off" className={classes.form}>
            <Grid container spacing={8} alignItems="flex-end">
                <Grid item xs={4}>
                    <FormControl className={classes.textField}>
                        <TextField
                            id="Name"
                            label="Nombre"
                            name="Name"
                            margin="normal"
                            value={Name || ''}
                            onChange={this.handleChange}
                            required={true}
                            onKeyPress={this.handleKeyPress}
                            error={errors && errors.some(e => e.source.toLowerCase() === 'Name')}
                        />
                    </FormControl>
                </Grid>
                <Grid item xs={12} style={{ textAlign: 'right' }}>
                    <Button
                        variant="contained"
                        className={classes.button}
                        onClick={() => { this.onCancel() }} >
                        Cancelar
                    </Button>
                    <Button
                        variant="contained"
                        color="primary"
                        className={classes.button}
                        onClick={() => { this.onSave() }} >
                        Guardar
                </Button>
                </Grid>
            </Grid>
        </form>;
    }
}

CategoryForm.propTypes = {
    classes: PropTypes.object.isRequired,
    saveHandler: PropTypes.func.isRequired,
    cancelHandler: PropTypes.func.isRequired
}

export default withStyles(styles)(CategoryForm);