import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import { connect } from 'react-redux';
import { Grid } from '@material-ui/core';
import Masonry from 'react-masonry-css'

import CategoryActions from '../../actions/CategoryActions';
import HuaList from '../../components/list/huaList';

const styles = theme => ({
    root: {
        width: '100%',
        marginTop: 120,
        maxWidth: 1140,
        marginLeft: 'auto',
        marginRight: 'auto'
    },
    myMasonryGrid: {
        display: 'flex',
        marginLeft: -50,
        width: '100%',
    },
    myMasonryGridColumn: {
        paddingLeft: 50,
        backgroundClip: 'padding-box'
    },
    myMasonryGridDiv: { 
        marginBottom: 70,
    }
});

const breakpointColumnsObj = {
    default: 3,
    700: 2,
    500: 1
};


class CategoryPublicPage extends React.Component {
    constructor() {
        super();

        this.state = {
            message: null,
            Errors: [],
            formData: null,
            collection: []
        }
    }

    componentDidMount() {
        this.fetchList(1, 100, "includeFaqs");
    }

    fetchList = (page, pageSize, filter, orderBy) => {
        this.props.fetchCategories(page, pageSize, filter, orderBy)
            .then(result => {
                this.setState({ collection: result.Data.Items});
            })
            .catch(result => {
                this.props.showError(result.Errors);
            });
    }

    render() {
        const { collection } = this.state;
        const { classes } = this.props;

        const childElements = collection.map(function(element, index){
            return (
                <div className={classes.myMasonryGridDiv} key={index}>
                    <HuaList collection={element.Faqs} title={element.Name} showSize={true} link="/faq/"></HuaList>
                </div>
             );
        });
        

        return (
            <div className={classes.root}>
                <Grid container spacing={24}>
                    <Masonry
                    breakpointCols={breakpointColumnsObj}
                    className={classes.myMasonryGrid}
                    columnClassName={classes.myMasonryGridColumn}
                    >
                        {childElements}
                    </Masonry>
                </Grid>
            </div>);
    }
}

CategoryPublicPage.propTypes = {
    fetchCategories: PropTypes.func.isRequired
}

export default connect(
    state => {
        return {
            authentication: state.authentication
        };
    },
    {
        fetchCategories: CategoryActions.fetchPageAction
    }
)(withStyles(styles)(CategoryPublicPage));