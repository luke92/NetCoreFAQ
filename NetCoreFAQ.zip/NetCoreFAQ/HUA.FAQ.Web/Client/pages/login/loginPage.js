﻿import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import { connect } from 'react-redux';
import Typography from '@material-ui/core/Typography'
import Paper from '@material-ui/core/Paper';

import LoginForm from './components/loginForm';
import TipoDeDocumentoActions from '../../actions/tipoDeDocumentoActions';
import { loginAction } from '../../actions/loginAction';
import { showError } from '../../actions/messageActions';

const styles = theme => ({
    button: {
        margin: theme.spacing.unit,
    },
    input: {
        display: 'none',
    },
    paper: {
        margin: '0 auto',// theme.spacing.unit * 20,
        marginTop: '140px',
        padding: theme.spacing.unit * 2,
        textAlign: 'center',
        color: theme.palette.text.secondary,
        width: '400px'
    }
});

class LoginPage extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            tiposDeDocumento: {}
        }
    }

    componentDidMount() {
        this.props.fetchTiposDeDocumento().then(
            (result) => {
                this.setState({tiposDeDocumento: result.data});
            },
            (result) => {
                this.props.showError(result.Errors);
            }
        );
    }

    onLogin = (tipoDeDocumentoId, numeroDeDocumento, password) => {
        this.props.login(tipoDeDocumentoId, numeroDeDocumento, password).then(
            (result) => {
                this.props.history.push("/login");
            },
            (result) => {
                this.props.showError(result.Errors);
            }
        );
    }

    render() {
        const { classes, login} = this.props;
        const { tiposDeDocumento } = this.state;

        if (this.props.authentication.isAuthenticated) {
            this.props.history.push("/");
        }
        return (
            <Paper className={classes.paper}>
                <center><img src="static/images/header_logo.png" /></center>
                <Typography variant="headline" color="inherit">
                    Ingreso al sistema
                </Typography>
                <LoginForm
                    loginHandler={this.onLogin}
                    tiposDeDocumento={tiposDeDocumento} />
            </Paper >
        );
    };
};

LoginPage.propTypes = {
    classes: PropTypes.object.isRequired,
    login: PropTypes.func.isRequired,
    fetchTiposDeDocumento: PropTypes.func.isRequired,
    showError: PropTypes.func.isRequired
}

export default connect(
    state => {
        return {
            authentication: state.authentication
        }
    },
    {
        login: loginAction,
        fetchTiposDeDocumento: TipoDeDocumentoActions.fetchPageAction,
        showError: showError
    }
)(withStyles(styles)(LoginPage));