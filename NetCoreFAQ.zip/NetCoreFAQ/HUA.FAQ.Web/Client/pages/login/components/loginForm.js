﻿import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';

import Button from '@material-ui/core/Button';
import Input from '@material-ui/core/Input';
import InputLabel from '@material-ui/core/InputLabel';
import MenuItem from '@material-ui/core/MenuItem';
import Typography from '@material-ui/core/Typography'
import Select from '@material-ui/core/Select';
import TextField from '@material-ui/core/TextField';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';

const styles = theme => ({
    form: {
        display: 'flex',
        alignItems: 'strech',
        justifyContent: 'space-evenly',
        flexFlow: 'column',
        padding: '20px'
    },
    button: {
        margin: theme.spacing.unit,
    },
    input: {
        display: 'none',
    },
});

class LoginForm extends React.Component {
    constructor(props) {
        super(props);

        this.state = {
            tipoDeDocumentoId: '331abbe6-f32f-4d16-8125-e6ecd157c642',
            numeroDeDocumento: '',
            password: ''
        }
    }

    handleChange = event => {
        this.setState({ [event.target.name]: event.target.value });
    }

    login = () => {
        const { tipoDeDocumentoId, numeroDeDocumento, password } = this.state;
        this.props.loginHandler(tipoDeDocumentoId, numeroDeDocumento, password);
    }

    render() {
        const { tipoDeDocumentoId, numeroDeDocumento, password } = this.state;
        const { classes, tiposDeDocumento } = this.props;

        let tiposDeDocumentoEl = null;

        if (tiposDeDocumento.items != undefined) {
            tiposDeDocumentoEl = tiposDeDocumento.items.map(item => {
                return <MenuItem key={item.id} value={item.id}>{item.nombre}</MenuItem>
            });
        }

        return (
            <form noValidate autoComplete="off" className={classes.form}>
                <FormControl style={{ padding: '0 0 6px 0' }} >
                    <InputLabel htmlFor="tipoDeDocumentoId">Tipo de Documento</InputLabel>
                    <Select
                        value={tipoDeDocumentoId}
                        onChange={this.handleChange}
                        input={<Input name="tipoDeDocumentoId" id="tipoDeDocumentoId" />}>
                        <MenuItem value="00000000-0000-0000-0000-000000000000">
                            <em>Seleccione un tipo de documento</em>
                        </MenuItem>
                        {tiposDeDocumentoEl}
                    </Select>
                </FormControl>
                <FormControl>
                    <TextField
                        id="numeroDeDocumento"
                        label="Número de Documento"
                        name="numeroDeDocumento"
                        margin="normal"
                        onChange={this.handleChange}
                        onKeyPress={(e) => {
                            if (e.key === 'Enter') {
                                this.login();
                            }
                        }}
                    />
                </FormControl>
                <FormControl>
                    <TextField
                        id="password"
                        label="Contraseña"
                        type="password"
                        name="password"
                        margin="normal"
                        onChange={this.handleChange}
                        onKeyPress={(e) => {
                            if (e.key === 'Enter') {
                                this.login();
                            }
                        }}
                        autoComplete="off"
                    />
                </FormControl>
                <Button
                    variant="contained"
                    color="primary"
                    className={classes.button}
                    onKeyPress={(e) => {
                        if (e.key === 'Enter') {
                            this.login();
                        }
                    }}
                    onClick={() => { this.login() }} >
                    Ingresar
                </Button>
            </form>
        );
    };
};

LoginForm.propTypes = {
    classes: PropTypes.object.isRequired,
    loginHandler: PropTypes.func.isRequired,
    tiposDeDocumento: PropTypes.object.isRequired
}

export default withStyles(styles)(LoginForm);