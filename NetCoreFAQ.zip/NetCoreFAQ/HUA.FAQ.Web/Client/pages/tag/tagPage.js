﻿import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import { connect } from 'react-redux';
import classNames from 'classnames';
import Paper from '@material-ui/core/Paper';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import AddIcon from '@material-ui/icons/Add';

import TagActions from '../../actions/tagActions';
import { showError, showSuccess } from '../../actions/messageActions';
import TagTable from './components/TagTable';
import TagForm from './components/TagForm';
import HuaConfirmationDialog from '../../components/form/huaConfirmDialog';
import { setTimeout } from 'core-js';

const styles = theme => ({
    root: {
        width: '100%',
        marginTop: 120,
        maxWidth: 1140,
        marginRight: 'auto',
        marginLeft: 'auto'
    },
    header: {
        paddingRight: theme.spacing.unit,
    },
    title: {
        flex: '0 0 auto',
    },
    button: {
        position: 'absolute',
        top: theme.spacing.unit * -4,
        right: theme.spacing.unit * 4,
    },
});

class TagPage extends React.Component {
    constructor() {
        super();

        this.state = {
            message: null,
            Errors: [],
            formData: null,
            collection: {}
        }
    }

    componentDidMount() {
        this.fetchList(1, 10);
    }

    reloadList = () => {
        const { collection } = this.state;
        this.fetchList(collection.Page, collection.PageSize, collection.filter, collection.OrderBy[0].Key);
    }

    fetchList = (page, pageSize, filter, orderBy) => {
        this.props.fetchTags(page, pageSize, filter, orderBy)
            .then(result => {
                this.setState({ collection: result.Data, formData: null, Errors: null, itemToRemove: null });
            })
            .catch(result => {
                this.props.showError(result.Errors);
            });
    }

    onSortChange = (event, property) => {
        if (event) {
            const { collection } = this.state;

            if (property === collection.orderBy) {
                property += ' desc';
            }

            this.fetchList(collection.Page, collection.PageSize, collection.filter, property);
        }
    }

    onPageChange = (event, page) => {
        if (event) {
            
            const { collection } = this.state;
            this.fetchList(page + 1, collection.PageSize, collection.filter, collection.OrderBy[0].Key);
        }
    }

    onRowsPerPageChange = event => {
        if (event) {
            const { collection } = this.state;
            this.fetchList(1, event.target.value, collection.filter, collection.OrderBy[0].Key);
        }
    }

    onCreateItem = () => {
        this.setState({
            formData: {
                id: '00000000-0000-0000-0000-000000000000',
                nombre: ''
            }
        })
    }

    onSelectItem = (item) => {
        //console.log('select', item);
    }

    onEditItem = (item) => {
        this.props.fetchTagById(item.Id).then(
            (result) => {
                this.setState({
                    formData: result.Data
                });
            },
            (result) => {
                this.props.showError(result.Errors);
            }
        );
    }

    onDeleteItem = (item) => {
        this.setState({ itemToRemove: item });
    }

    onDeleteConfirm = () => {
        const { itemToRemove } = this.state;
        this.props.deleteTag(itemToRemove).then(
            (result) => {
                this.props.showSuccess([{ Message: 'El Tag se eliminó con exito' }]);
                setTimeout(() => { this.reloadList(); }, 100);
            },
            (result) => {
                this.props.showError(result.Errors);
            }
        );
    }

    onDeleteCancel = () => {
        this.setState({ itemToRemove: null });
    }

    onSave = (item) => {
        if (item.id === '00000000-0000-0000-0000-000000000000') {
            this.props.createTag(item).then(
                (result) => {
                    this.props.showSuccess([{ Message: 'El Tag se creó con exito' }]);
                    setTimeout(() => { this.reloadList(); }, 100);
                },
                (result) => {
                    this.setState({ Errors: result.Errors });
                    this.props.showError(result.Errors);
                }
            );
        }
        else {
            this.props.updateTag(item).then(
                (result) => {
                    this.props.showSuccess([{ Message: 'El Tag se actualizó con exito' }]);
                    setTimeout(() => { this.reloadList(); }, 100);
                },
                (result) => {
                    this.setState({ Errors: result.Errors });
                    this.props.showError(result.Errors);
                }
            );
        }
    }

    onCancel = () => {
        this.reloadList();
    }

    render() {
        const { collection, formData, errors, itemToRemove } = this.state;
        const { classes, tag } = this.props;

        if (!this.props.authentication.isAuthenticated) {
            this.props.history.push("/login");
        }

        return <div>
            {!formData && <Paper className={classes.root}>
                <Toolbar
                    className={classNames(classes.header)}>
                    <div className={classes.title}>
                        <Typography variant="title" id="tableTitle">
                            Tags
                        </Typography>
                        <Button
                            variant="fab"
                            color="primary"
                            aria-label="Agregar"
                            className={classes.button}
                            onClick={() => this.onCreateItem()}>
                            <AddIcon />
                        </Button>
                    </div>
                </Toolbar>
                <TagTable
                    collection={collection}
                    changeSortHandler={this.onSortChange}
                    changePageHandler={(event, page) => this.onPageChange(event, page)}
                    changeRowsPerPageHandler={(event) => this.onRowsPerPageChange(event)}
                    editRowHandler={(row) => this.onEditItem(row)}
                    deleteRowHandler={(row) => this.onDeleteItem(row)}
                    selectRowHandler={(row) => this.onSelectItem(row)}
                />
            </Paper>}

            {
                formData &&
                <Paper className={classes.root}>
                    <Toolbar
                        className={classNames(classes.header)}>
                        <div className={classes.title}>
                            <Typography variant="title" id="tableTitle">
                                Tags
                        </Typography>
                        </div>
                    </Toolbar>
                    <TagForm
                        formData={formData} errors={errors}
                        saveHandler={(item) => this.onSave(item)}
                        cancelHandler={() => this.onCancel()}
                    />
                </Paper>
            }

            {
                itemToRemove &&
                <HuaConfirmationDialog
                    title="Eliminar Tag"
                    open={true}
                    body={`Seguro de eliminar el Tag ${itemToRemove.name}?`}
                    closeHandler={this.onDeleteCancel}
                    yesHandler={this.onDeleteConfirm}
                    noHandler={this.onDeleteCancel}
                />
            }
        </div>;
    }
}

TagPage.propTypes = {
    classes: PropTypes.object.isRequired,
    fetchTags: PropTypes.func.isRequired,
    fetchTagById: PropTypes.func.isRequired,
    createTag: PropTypes.func.isRequired,
    updateTag: PropTypes.func.isRequired,
    deleteTag: PropTypes.func.isRequired
}

export default connect(
    state => {
        return {
            authentication: state.authentication
        };
    },
    {
        fetchTags: TagActions.fetchPageAction,
        fetchTagById: TagActions.fetchByIdAction,
        createTag: TagActions.createAction,
        updateTag: TagActions.updateAction,
        deleteTag: TagActions.deleteAction,
        showError: showError,
        showSuccess: showSuccess
    }
)(withStyles(styles)(TagPage));