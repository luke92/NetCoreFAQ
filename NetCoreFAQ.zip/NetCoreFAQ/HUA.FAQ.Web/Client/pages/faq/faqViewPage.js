import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import FaqActions from '../../actions/faqActions';
import FaqRatingActions from '../../actions/faqRatingActions';
import { showError } from '../../actions/messageActions';
import FroalaEditorView from 'react-froala-wysiwyg/FroalaEditorView';
import Chip from '@material-ui/core/Chip';
import Avatar from '@material-ui/core/Avatar';
import { Link } from 'react-router-dom';
import Button from '@material-ui/core/Button';
import classNames from 'classnames';

import { StarBorder, RemoveRedEyeOutlined } from '@material-ui/icons';

import HuaList from '../../components/list/huaList';
import { withStyles } from '@material-ui/core/styles';
import { Grid, Typography, Card, CardContent } from '@material-ui/core';

import FaqQualify from './components/faqQualify';
import FaqGratitude from './components/faqGratitude';



// Moment
import Moment from 'react-moment';

const styles = theme => ({
    root: {
        width: '100%',
        maxWidth: 1140,
        marginLeft: 'auto',
        marginRight: 'auto',
        marginTop: 140,
        marginBottom: 100,
        color: '#6c6b6a',
    },
    avatar: {
        width: 60,
        height: 60,
        cursor: 'pointer',
        backgroundColor: theme.palette.secondary.main,
        borderColor: 'solid 1px #CCD0D3'
    },
    icon: {
        fontSize: 20,
        marginLeft: 15,
        marginRight: 8,
        color: '#6c6b6a',
    },
    title: {
        color: '#6E9EC3',
        fontSize: 36,
        fontWeight: 500,
        marginBottom: 30
    },
    solution: {
        marginBottom: 30
    },
    stats: {
        marginTop: 10,
        marginBottom: 50
    },
    date: {
        marginTop: 5,
        fontSize: 12,
        color: '#6c6b6a',
        fontWeight: 500,
    },
    mainContainer: {
        paddingLeft: '40px!important',
        paddingRight: '40px!important'
    },
    secondaryContainer: {
        padding: '20px!important',
        borderLeft: '1px solid #CCD0D3'
    },
    Gratitude: {
        marginTop: 100,
        marginBottom: 100
    }
});
class FaqViewPage extends React.Component {

    constructor() {
        super();

        this.state = {
            formData: null,
            collectionRelatedFaqs: [],
            collectionFromUser: [],
            showComponent: true
        };
    }

    componentDidMount() {
        this.onShow({ Id: this.props.match.params.Id });
    }

    componentWillReceiveProps(props) {

        if (props.match.params.Id != this.props.match.params.Id) {
            this.onShow({ Id: props.match.params.Id });
        }
    }

    handleClickYes = () => {
        this.setState({
            showComponent: false
        });
        this.props.addRating(this.state.formData.Id).then(
            (result) => {
                this.setState({
                    formData: result.Data
                });
            });
    }

    handleClickNo = () => {
        this.setState({
            showComponent: false
        });
    }

    renderQuestionGratitude() {
        if (this.state.showComponent) {
            return (<FaqQualify onClickYes={this.handleClickYes} onClickNo={this.handleClickNo} />);
        }
        else
            return (<FaqGratitude />);
    }

    onShow = (item) => {

        this.props.fetchFaqById(item.Id).then(
            (result) => {
                this.setState({
                    formData: result.Data,
                    showComponent: true
                });

                // Buscamos más post del usuario
                this.props.fetchFaqs(1, 5, 'CreatedUser=' + result.Data.CreatedUser + '&!Id=' + result.Data.Id).then(
                    (result) => {
                        this.setState({
                            collectionFromUser: result.Data.Items
                        });
                    },
                    (result) => {
                        this.props.showError(result.Errors);
                    });

                //Buscamos tag relacionados al faq
                this.props.fetchFaqs(1, 5, 'RelatedId=' + result.Data.Id + '&!Id=' + result.Data.Id).then(
                    (result) => {
                        this.setState({
                            collectionRelatedFaqs: result.Data.Items
                        });
                    },
                    (result) => {
                        this.props.showError(result.Errors);
                    });
            },
            (result) => {
                this.props.showError(result.Errors);
            }
        );
    }

    render() {

        const { formData, collectionRelatedFaqs, collectionFromUser } = this.state;
        const { classes } = this.props;

        if (!formData) {
            return null;
        }
        // TODO: Traer esto desde el backend
        //formData.stars = 17;

        let firstLetter = "";
        if (!formData.Avatar && formData.CreatedUser) {
            firstLetter = formData.CreatedUser[0];
        }

        return (
            <div className={classes.root}>
                <Card elevation={7}>
                    <CardContent>
                        <Grid container spacing={24} >
                            <Grid item xs={9} container className={classes.mainContainer}
                                direction="column"
                                justify="flex-start"
                                alignItems="flex-start">
                                <Grid item>
                                    <Typography variant="headline" component="h1" className={classes.title}>
                                        {formData.Name}
                                    </Typography>
                                </Grid>
                                <Grid item className={classes.solution}>
                                    <FroalaEditorView model={formData.Solution} />
                                </Grid>
                                <Grid item container spacing={16}>
                                    {
                                        formData.Tags &&
                                        formData.Tags.map((item, index) => {
                                            return <Grid item key={index} >

                                                <Link to={'/faq?TagId=' + item.Id}>
                                                    <Chip
                                                        clickable
                                                        key={item.Id}
                                                        label={item.Name} />
                                                </Link>

                                            </Grid>
                                        })
                                    }
                                </Grid>
                                <Grid container container direction="row" justify="center" alignItems="center" className={classes.Gratitude}>
                                    <Grid item>
                                        {this.renderQuestionGratitude()}
                                    </Grid>
                                </Grid>

                            </Grid>
                            <Grid item container xs={3} className={classes.secondaryContainer} direction="column" justify="flex-start" alignItems="flex-start">
                                <Grid item container direction="row" justify="center" alignItems="center">
                                    <Grid item container direction='row' alignItems='center' justify='center' xs={5}>
                                        <Avatar
                                            alt={formData.CreatedUser}
                                            src={formData.Avatar}
                                            className={classes.Avatar}
                                        >{firstLetter}</Avatar>
                                    </Grid>
                                    <Grid item container direction='column' justify="flex-start" alignItems="flex-start" xs={7}>
                                        <Grid item >
                                            <Link to="#">{formData.CreatedUser}</Link>
                                        </Grid>

                                        <Grid item>
                                            <Moment className={classes.date} format="DD-MM-YYYY HH:mm">
                                                {formData.CreatedDate}
                                            </Moment>
                                        </Grid>
                                    </Grid>
                                </Grid>
                                <Grid item container direction='row' alignItems='center' justify="center" className={classes.stats}>
                                    <StarBorder className={classes.icon} />
                                    <label>{formData.Rating}</label>
                                    <RemoveRedEyeOutlined className={classes.icon} />
                                    <label>{formData.Visits}</label>
                                </Grid>
                                <Grid item className={classes.listItemFaq}>
                                    <HuaList collection={collectionRelatedFaqs} title={"Artículos relacionados"} link="/faq/" />
                                </Grid>

                                <Grid item className={classes.listItemFaq}>
                                    <HuaList collection={collectionFromUser} title={"Artículos del autor"} link="/faq/" />
                                </Grid>

                            </Grid>
                        </Grid>
                    </CardContent>
                </Card>
            </div >
        );
    }
}

FaqViewPage.propTypes = {
    addRating: PropTypes.func.isRequired,
    fetchFaqById: PropTypes.func.isRequired,
    fetchFaqs: PropTypes.func.isRequired
}

export default connect(
    (state) => {
        return {

        }
    },
    {
        addRating: FaqRatingActions.addRating,
        fetchFaqById: FaqActions.fetchByIdAction,
        fetchFaqs: FaqActions.fetchPageAction,
        showError: showError
    }
)(withStyles(styles)(FaqViewPage));