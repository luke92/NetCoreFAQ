import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import FaqActions from '../../actions/faqActions';

import HuaCardList from '../../components/card/huaCardList';
import { withStyles } from '@material-ui/core/styles';
import { Link } from 'react-router-dom';
import { Grid, Typography } from '@material-ui/core';

import queryString from 'query-string';

const styles = theme => ({
    root: {
        width: '100%',
        maxWidth: 1140,
        marginLeft: 'auto',
        marginRight: 'auto',
        marginTop: 120,
    },
});
class FaqPublicPage extends React.Component {

    constructor(){
        super();

        this.state = {
            collection : {}
        };
    }

    componentWillMount() {
        this.search(this.props.location.search);
    }

    componentWillReceiveProps(props) {
        
        if (props.location.search != this.props.location.search){
            this.search(props.location.search);
        }
    }

    handlePageChange = (current, pageSize) => {

        let urlParameters = queryString.parse(this.props.location.search);

        urlParameters.Page = current;

        let stringUrlParameter = queryString.stringify(urlParameters);

        this.props.history.push(`/faq?${stringUrlParameter}`);

        this.search(stringUrlParameter);
    }

    search = (url) => {

        let urlParameters = queryString.parse(url)

        let page = urlParameters.Page || 1;
        let pageSize = urlParameters.pasesize || 10;
        let orderby = urlParameters.orderby || null; 

        // Las propiedades restantes corresponden al filtro
        urlParameters.Page = urlParameters.pasesize = urlParameters.orderby = undefined;
        
        let filter = queryString.stringify(urlParameters);
        
        this.fetchList(page, pageSize, filter, orderby);
    }

    fetchList = (page, pageSize, filter, orderBy) => {
        this.props.fetchFaqs(page, pageSize, filter, orderBy)
            .then(result => {
                this.setState({ collection: result.Data });
            })
            .catch(result => {
                this.props.showError(result.Errors);
            });
    }

    render() {

        const { collection } = this.state;
        const { classes } = this.props;
        
        return (
            <div className={classes.root}>
                <Grid container spacing={24}>
                    <HuaCardList 
                        collection = { collection }
                        handlePageChange = { this.handlePageChange }
                    />
                </Grid>
            </div>
        );
    }
}

FaqPublicPage.propTypes = {
    fetchFaqs: PropTypes.func.isRequired
}

export default connect( 
    (state) => {
        return {

        }
    },
    {
        fetchFaqs: FaqActions.fetchPageAction
    }
)(withStyles(styles)(FaqPublicPage));