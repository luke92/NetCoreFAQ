﻿import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import { withStyles } from '@material-ui/core/styles';
import { Grid, Typography, Card, CardContent } from '@material-ui/core';
import Button from '@material-ui/core/Button';
import { ThumbDownOutlined, ThumbUpOutlined } from '@material-ui/icons';

const styles = theme => ({
    groupUtil: {
        marginTop: 10,
        marginLeft: 'auto',
        marginRight: 'auto',
        height: 92,
        width: 348
    },
    util: {
        marginTop: 10,
        marginLeft: 'auto',
        marginRight: 'auto',
        height: 28,
        width: 348,
        color: '#2F3439',
        fontSize: 24,
        fontWeight: 500,
        textAlign: 'center',
        marginBottom: 50
    },
    buttonUtil: {
        marginLeft: 'auto',
        marginRight: 'auto',
        height: 41,
        width: 118,
        border: '1px solid #979797',
        borderRadius: 3,
        backgroundColor: '#FFFFFF'
    },
    checkMaterial: {
        height: 18,
        width: 19.2,
        color: '#5D7C3B',
        fontSize: 18,
        lineHeight: 'NaNpx'
    },
    closeMaterial: {
        height: 18,
        width: 19.2,
        color: '#E37070',
        fontSize: 18,
        lineHeight: 'NaNpx'
    },
    textButtonUtil: {
        height: 24,
        width: 24,
        textTransform: 'capitalize',
        color: '#2F3439',
        fontSize: 18
    },
});

class FaqQualify extends React.Component {

    handleClickYes = () => {
        this.props.onClickYes();
    };

    handleClickNo = () => {
        this.props.onClickNo();
    };

    render() {
        const { classes } = this.props;
        return (
            <Grid container className={classes.groupUtil}>
                <Grid item xs={12} className={classes.util}>
                    <Typography variant="headline" component="h1">
                        ¿Te resultó útil este artículo?
                </Typography>
                </Grid>
                <Grid item container className={classes.buttonUtil} component={Button} onClick={this.handleClickYes} >
                    <ThumbUpOutlined className={classes.icon} />
                    <Grid item><Typography className={classes.textButtonUtil}>Si</Typography></Grid>
                </Grid>
                <Grid item className={classes.buttonUtil} component={Button} onClick={this.handleClickNo}>
                    <ThumbDownOutlined className={classes.icon} />
                    <Typography className={classes.textButtonUtil}>No</Typography>
                </Grid>
            </Grid>
        );
    }
}

export default withStyles(styles)(FaqQualify);