﻿import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import HuaTable from '../../../components/table/huaTable';

const styles = theme => ({
});

const tableStructure = [
    { id: 'Name', label: 'Nombre'},
    { id: 'CreatedDate', label: 'Fecha de Creación'}
];

class FaqTable extends React.Component {
    render() {
        const {
            classes,
            collection,
            changePageHandler,
            changeRowsPerPageHandler,
            changeSortHandler,
            editRowHandler,
            deleteRowHandler,
            selectRowHandler
        } = this.props;

        return <div>
            <HuaTable
        structure={tableStructure}
        collection={collection}
        changeSortHandler={changeSortHandler}
        changePageHandler={(event, page) => changePageHandler(event, page)}
    changeRowsPerPageHandler={(event) => changeRowsPerPageHandler(event)}
editRowHandler={(row) => editRowHandler(row)}
deleteRowHandler={(row) => deleteRowHandler(row)}
selectRowHandler={(row) => selectRowHandler(row)}
/>
</div>;
}
}

FaqTable.propTypes = {
    classes: PropTypes.object.isRequired,
    collection: PropTypes.object.isRequired,
    changePageHandler: PropTypes.func.isRequired,
    changeRowsPerPageHandler: PropTypes.func.isRequired,
    changeSortHandler: PropTypes.func.isRequired,
    editRowHandler: PropTypes.func.isRequired,
    deleteRowHandler: PropTypes.func.isRequired,
    selectRowHandler: PropTypes.func.isRequired
}

export default withStyles(styles)(FaqTable);