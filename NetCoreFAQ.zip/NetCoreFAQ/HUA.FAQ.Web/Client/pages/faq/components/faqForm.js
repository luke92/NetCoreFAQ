﻿import React from 'react';
import PropTypes from 'prop-types';
import BaseForm from '../../../components/form/baseForm';
import { withStyles } from '@material-ui/core/styles';
import Button from '@material-ui/core/Button';
import TextField from '@material-ui/core/TextField';
import FormControl from '@material-ui/core/FormControl';
import Grid from '@material-ui/core/Grid';
import SimpleSelect from '../../../components/form/simpleSelectCategory';
import SelectMultipleMaterialUI from '../../../components/form/selectMultiple';

// Require Editor JS files.
import 'froala-editor/js/froala_editor.pkgd.min.js';

// Require Editor CSS files.
import 'froala-editor/css/froala_style.min.css';
import 'froala-editor/css/froala_editor.pkgd.min.css';

// Require Font Awesome.
import 'font-awesome/css/font-awesome.css';

import FroalaEditor from 'react-froala-wysiwyg';

const styles = theme => ({
    form: {
        display: 'flex',
        flexWrap: 'wrap',
        padding: '20px',
        maxWidth: 700,
        marginLeft: 'auto',
        marginRight: 'auto'
    },
    textField: {
        marginLeft: theme.spacing.unit,
        marginRight: theme.spacing.unit,
        width: '100%'
    },
    button: {
        margin: theme.spacing.unit,
    },
    input: {
        display: 'none',
    },
    root: {
        display: 'flex',
        flexWrap: 'wrap',
    },
    formControl: {
        margin: theme.spacing.unit,
        minWidth: 120,
    },
    selectEmpty: {
        marginTop: theme.spacing.unit * 2,
    },
    froalaContainer: {
        marginTop: 50,
        marginBottom: 30
    }

});

class FaqForm extends BaseForm {


    handleChangeSelect = event => {
        this.setState({ [event.target.name]: event.target.value });
    };

    handleSolutionChange = (Solution) => {
        const { formData } = this.state;
        formData['Solution'] = Solution;
        this.setState({ formData });
    }

    handleClickChangeTag = (Tags) => {
        const { formData } = this.state;
        formData['Tags'] = Tags;
        this.setState({ formData });
    }

    handleClickChangeCategory = (Category) => {
        const { formData } = this.state;
        formData['Category'] = { id: Category };
        this.setState({ formData });
    }

    render() {
        const {
            Id,
            Name,
            Description,
            Solution,
            Category,
            Tags,
        } = this.state.formData;
        const { classes, errors } = this.props;
        const config = {
            placeholder: "Edit Me",
            events : {
                'froalaEditor.image.beforeUpload' : function(e, editor, files) {
                    if (files.length) {
                        // Create a File Reader.
                        var reader = new FileReader();
                   
                        // Set the reader to insert images when they are loaded.
                        reader.onload = function (e) {
                          var result = e.target.result;
                          editor.image.insert(result, null, null, editor.image.get());
                        };
                        
                        // Read image as base64.
                        reader.readAsDataURL(files[0]);
                    }
                  
                    editor.popups.hideAll();
                  
                    // Stop default upload chain.
                    return false;
                }
            },
            toolbarSticky: false,
            charCounterCount: false,
            height: 300,
            ket: 'NOPE',
            toolbarButtons: ['fullscreen', 'bold', 'italic', 'underline', 'strikeThrough', 'subscript', 'superscript', '|', 'fontFamily', 'fontSize', 'color', 'inlineStyle', 'paragraphStyle', '|', 'paragraphFormat', 'align', 'formatOL', 'formatUL', 'outdent', 'indent', 'quote', '|', 'insertLink', 'insertImage', 'insertVideo', 'embedly', 'insertTable', '|', 'specialCharacters', 'insertHR', 'selectAll', 'clearFormatting', 'html', '|', 'undo', 'redo']
        };
        

        return <form noValidate autoComplete="off" className={classes.form}>
            <Grid container spacing={24} alignItems="flex-end">
                <Grid item xs={12} >
                    <FormControl className={classes.textField}>
                        <TextField
                            id="Name"
                            label="Nombre"
                            name="Name"
                            margin="normal"
                            value={Name || ''}
                            onChange={this.handleChange}
                            required={true}
                            onKeyPress={this.handleKeyPress}
                            error={errors && errors.some(e => e.source.toLowerCase() === 'name')}
                        />
                        <TextField
                            id="Description"
                            label="Descripción"
                            name="Description"
                            margin="normal"
                            value={Description || ''}
                            onChange={this.handleChange}
                            required={true}
                            onKeyPress={this.handleKeyPress}
                            error={errors && errors.some(e => e.source.toLowerCase() === 'Description')}
                        />
                        <Grid className={classes.froalaContainer}>
                            <FroalaEditor
                                tag='textarea'
                                config={config}
                                model={Solution || ''}
                                onModelChange={this.handleSolutionChange}
                            />
                        </Grid>
                        <SimpleSelect
                            onChangeCategory={(Category) => this.handleClickChangeCategory(Category)}
                            id="Category"
                            name="Category"
                            selectedValue={Category || ''}
                        />
                        <SelectMultipleMaterialUI
                            onChangeTags={(Tags) => this.handleClickChangeTag(Tags)}
                            id="Tags"
                            name="Tags"
                            selectedValues={Tags}

                        />

                    </FormControl>

                </Grid>
                <Grid item xs={12} style={{ textAlign: 'right' }}>
                    <Button
                        variant="contained"
                        className={classes.button}
                        onClick={() => { this.onCancel() }} >
                        Cancelar
                    </Button>
                    <Button
                        variant="contained"
                        color="primary"
                        className={classes.button}
                        onClick={() => { this.onSave() }} >
                        Guardar
                </Button>
                </Grid>
            </Grid>
        </form>;
    }
}

FaqForm.propTypes = {
    classes: PropTypes.object.isRequired,
    saveHandler: PropTypes.func.isRequired,
    cancelHandler: PropTypes.func.isRequired
}

export default withStyles(styles)(FaqForm);