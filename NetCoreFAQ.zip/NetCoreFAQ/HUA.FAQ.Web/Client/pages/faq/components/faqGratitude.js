﻿import React from 'react';
import PropTypes from 'prop-types';
import classNames from 'classnames';
import { withStyles } from '@material-ui/core/styles';
import VerySatisfied from '@material-ui/icons/SentimentVerySatisfied';
import { Grid, Typography, Card, CardContent } from '@material-ui/core';

const styles = theme => ({
    groupUtil: {
        marginTop: 10,
        marginLeft: 'auto',
        marginRight: 'auto',
        height: 92,
        width: 348
    },
    panelBody: {
        padding: 15
    },
    divInside: {
        textAlign: 'center',
    },
    materialIcons: {
        width: 70,
        height: 70,
        fontSize: '70px',
        color: 'gray',
        fontFamily: 'Material Icons',
        fontWeight: 400,
        fontStyle: 'normal',
        lineHeight: 1,
        letterSpacing: 'normal',
        textTransform: 'none',
        display: 'inline-Block',
        wordWrap: 'normal'
    },
    divBottom: {
        textAlign: 'center',
        fontSize: 20,
    }
});
class FaqGratitude extends React.Component {

    render() {
        const { classes } = this.props;
        return (
        <Grid container className={classes.groupUtil}>
            <div className= { classes.panelBody } id="opciones-calificacion">
                <div className= { classes.divInside }>
                    <VerySatisfied className={classes.materialIcons} />
                </div>
                <div className= { classes.divBottom }>Gracias por calificar la pregunta!</div>
            </div>
            </Grid>
        );
    }
}

export default withStyles(styles)(FaqGratitude);