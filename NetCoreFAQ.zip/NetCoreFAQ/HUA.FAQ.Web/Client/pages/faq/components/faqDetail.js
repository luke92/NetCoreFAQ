import React from 'react';
import { Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import Typography from '@material-ui/core/Typography';
import Avatar from '@material-ui/core/Avatar';
import Grid from '@material-ui/core/Grid';
import { StarBorder, RemoveRedEyeOutlined } from '@material-ui/icons';
import Chip from '@material-ui/core/Chip';

import FroalaEditorView from 'react-froala-wysiwyg/FroalaEditorView';

const styles = theme => ({
    media: {
        height: 0,
        paddingTop: '56.25%', // 16:9
    },
    title: {
        color: '#6E9EC3',
        fontFamily: 'Roboto',
        fontWeight: 500,
    },
    body: {
        color: '#6c6b6a',
        fontFamily: 'Roboto',
        width: '100%'
    },
    avatar: {
        width: 35,
        height: 35,
    },
    name: {
        color: '#2A9FD8',
        fontFamily: 'Roboto',
        fontWeight: 500,
        fontSize: 12
    },
    date: {
        color: '#6c6b6a',
        fontFamily: 'Roboto',
        fontWeight: 500,
        fontSize: 12
    },
    avatar: {
        margin: 10,
        marginRight: -5,
        cursor: 'pointer',
        backgroundColor: theme.palette.secondary.main,
        borderColor: 'solid 1px #CCD0D3'
    },
    icon: {
        fontSize: 20,
        marginLeft: 15,
        marginRight: 8
    },
    cardAction: {
        borderTop: 'solid 1px #CCD0D3',
        Color: '#6c6b6a'
    },
    card: {
        marginBottom: 15,
        marginTop: 15,
        border: 'solid 1px #CCD0D3'
    },
    cardWithOutBorder: {
        marginBottom: 15,
        marginTop: 15
    }
});

class HuaCardListItem extends React.Component {

    render() {

        const { classes,
            title,
            body,
            avatar,
            user,
            date,
            visits,
            rating,
            tags,
            withOutBorder } = this.props;

        let cardStyle = classes.card;

        let { elevation } = this.state;

        let firstLetter = "";
        if (!avatar && user) {
            firstLetter = user[0];
        }

        if (withOutBorder) {
            elevation = 0;
            cardStyle = classes.cardWithOutBorder;
        }

        return <div className={classes.body} >
            <Grid item container spacing={16}>
                <Grid item xs={12}>
                    <Typography variant="headline" component="h1" className={classes.title}>
                        {title}
                    </Typography>
                </Grid>
                <Grid item xs={12}>
                    <FroalaEditorView model={body} />
                </Grid>

                <Grid item container xs={12} spacing={16}>
                    {
                        tags &&
                        tags.map((item, index) => {
                            return <Grid item key={index} >

                                    <Link to={'/faq?TagId=' + item.Id}>
                                    <Chip
                                            clickable
                                            key={item.Id}
                                            label={item.Name} />
                                    </Link>
                            </Grid>
                        })
                    }
                </Grid>
                

            </Grid>
            <Card className={cardStyle} elevation={elevation}>
                <CardContent>

                </CardContent>
                <CardActions className={classes.cardAction}>
                    <Grid container>

                        <Grid item container xs={6} justify="flex-start">

                            <Grid item container direction='row' alignItems='center' justify='center' xs={5}>
                                <Avatar
                                    alt={user}
                                    src={avatar}
                                    className={classes.avatar}
                                >{firstLetter}</Avatar>
                            </Grid>

                            <Grid item container direction='column' justify='center' xs={7}>

                                <Grid item>
                                    <label className={classes.name}>{user}</label>
                                </Grid>

                                <Grid item>
                                    <label className={classes.date}>{date}</label>
                                </Grid>

                            </Grid>

                        </Grid>

                        <Grid item container direction='row' justify='center' xs={6}>

                            <Grid item container direction='row' alignItems='center' justify="flex-end">
                                <Grid item>
                                    <StarBorder className={classes.icon} />
                                </Grid>
                                <Grid item>
                                    <label className={classes.date}> { rating }</label>
                                </Grid>
                                <Grid item>
                                    <RemoveRedEyeOutlined className={classes.icon} />
                                </Grid>
                                <Grid item>
                                    <label className={classes.date}>{visits}</label>
                                </Grid>
                            </Grid>

                        </Grid>

                    </Grid>

                </CardActions>
            </Card>
        </div>;
    }
}

HuaCardListItem.propTypes = {
    title: PropTypes.string.isRequired,
    body: PropTypes.string.isRequired,
    user: PropTypes.string.isRequired,
    date: PropTypes.string.isRequired,
    rating: PropTypes.number.isRequired,
    visits: PropTypes.number.isRequired,
    classes: PropTypes.object.isRequired,
    tags: PropTypes.array
};

export default withStyles(styles)(HuaCardListItem);