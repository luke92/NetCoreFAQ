﻿import React from 'react';
import PropTypes from 'prop-types';
import { withStyles } from '@material-ui/core/styles';
import { connect } from 'react-redux';
import classNames from 'classnames';
import Paper from '@material-ui/core/Paper';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Button from '@material-ui/core/Button';
import AddIcon from '@material-ui/icons/Add';

import FaqActions from '../../actions/faqActions';
import { showError, showSuccess } from '../../actions/messageActions';
import FaqTable from './components/FaqTable';
import FaqForm from './components/FaqForm';
import HuaConfirmationDialog from '../../components/form/huaConfirmDialog';
import { setTimeout } from 'core-js';

import SearchIcon from '@material-ui/icons/Search';
import InputBase from '@material-ui/core/InputBase';
import { fade } from '@material-ui/core/styles/colorManipulator';

const styles = theme => ({
    root: {
        width: '100%',
        marginTop: 120,
        maxWidth: 1140,
        marginRight: 'auto',
        marginLeft: 'auto'
    },
    header: {
        paddingRight: theme.spacing.unit,
    },
    title: {
        flex: '0 0 auto',
    },
    button: {
        position: 'absolute',
        top: theme.spacing.unit * -4,
        right: theme.spacing.unit * 4,
    },
    search: {
        position: 'relative',
        borderRadius: theme.shape.borderRadius,
        backgroundColor: fade(theme.palette.common.white, 0.15),
        '&:hover': {
            backgroundColor: fade(theme.palette.common.white, 0.25),
        },
        marginLeft: 0,
        width: '100%',
        [theme.breakpoints.up('sm')]: {
            marginLeft: theme.spacing.unit,
            width: 'auto',
        },
    },
    searchIcon: {
        width: theme.spacing.unit * 9,
        height: '100%',
        position: 'absolute',
        pointerEvents: 'none',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
    },
    inputRoot: {
        color: 'inherit',
        width: '100%',
    },
    inputInput: {
        paddingTop: theme.spacing.unit,
        paddingRight: theme.spacing.unit,
        paddingBottom: theme.spacing.unit,
        paddingLeft: theme.spacing.unit * 10,
        transition: theme.transitions.create('width'),
        width: '100%',
        [theme.breakpoints.up('sm')]: {
            width: 120,
            '&:focus': {
                width: 200,
            },
        },
    },
});

class FaqPage extends React.Component {
    constructor() {
        super();

        this.state = {
            message: null,
            Errors: [],
            formData: null,
            collection: {}
        }
    }

    componentDidMount() {
        this.fetchList(1, 10);
    }

    reloadList = () => {
        const { collection } = this.state;
        this.fetchList(collection.Page, collection.PageSize, collection.filter, collection.orderBy);
    }

    fetchList = (page, pageSize, filter, orderBy) => {
        this.props.fetchFaqs(page, pageSize, filter, orderBy)
            .then(result => {
                this.setState({ collection: result.Data, formData: null, Errors: null, itemToRemove: null });
            })
            .catch(result => {
                this.props.showError(result.Errors);
            });
    }

    onSortChange = (event, property) => {        
        if (event) {
            const { collection } = this.state;

            if (property === collection.orderBy) {
                property += ' desc';
            }

            this.fetchList(collection.Page, collection.PageSize, collection.Filter === "" ? "" : "query=" + collection.Filter, property);
        }
    }

    onSearchChange = (event, property) => {
        if (event) {
            const { collection } = this.state;
            // Al ser una busqueda se pone la primera pagina. Se mantiene el Order By
            // Se pone query= para que el diccionario obtenga ocrrectamente el dato.
            this.fetchList(1, collection.PageSize, property === "" ? "" : "query=" + property, collection.OrderBy[0].Key);
        }
    }

    onPageChange = (event, page) => {
        if (event) {
            const { collection } = this.state;
            this.fetchList(page + 1, collection.PageSize, collection.Filter === "" ? "" : "query=" + collection.Filter, collection.OrderBy[0].Key);
        }
    }

    onRowsPerPageChange = event => {
        if (event) {
            const { collection } = this.state;
            this.fetchList(1, event.target.value, collection.Filter === "" ? "" : "query=" + collection.Filter, collection.OrderBy[0].Key);
        }
    }

    onCreateItem = () => {
        this.setState({
            formData: {
                Id: '00000000-0000-0000-0000-000000000000'
            }
        })
    }

    onSelectItem = (item) => {
        //console.log('select', item);
    }

    onEditItem = (item) => {
        this.props.fetchFaqById(item.Id).then(
            (result) => {
                this.setState({
                    formData: result.Data
                });
            },
            (result) => {
                this.props.showError(result.Errors);
            }
        );
    }

    onDeleteItem = (item) => {
        this.setState({ itemToRemove: item });
    }

    onDeleteConfirm = () => {
        const { itemToRemove } = this.state;
        this.props.deleteFaq(itemToRemove).then(
            (result) => {
                this.props.showSuccess([{ Message: 'La FAQ se eliminó con exito' }]);
                setTimeout(() => { this.reloadList(); }, 100);
            },
            (result) => {
                this.props.showError(result.Errors);
            }
        );
    }

    onDeleteCancel = () => {
        this.setState({ itemToRemove: null });
    }

    onSave = (item) => {
        if (item.Id === '00000000-0000-0000-0000-000000000000') {
            this.props.createFaq(item).then(
                (result) => {
                    setTimeout(() => { this.reloadList(); }, 100);
                },
                (result) => {
                    this.setState({ Errors: result.Errors });
                    this.props.showError(result.Errors);
                }
            );
        }
        else {
            this.props.updateFaq(item).then(
                (result) => {
                    console.log(result);
                    this.props.showSuccess([{ Message: 'La FAQ se actualizó con exito' }]);
                    setTimeout(() => { this.reloadList(); }, 100);
                },
                (result) => {
                    this.setState({ Errors: result.Errors });
                    this.props.showError(result.Errors);
                }
            );
        }
    }

    onCancel = () => {
        this.reloadList();
    }

    render() {
        const { collection, formData, errors, itemToRemove } = this.state;
        const { classes, faq } = this.props;

        if (!this.props.authentication.isAuthenticated) {
            this.props.history.push("/login");
        }

        return <div>
            {!formData && <Paper className={classes.root}>
                <Toolbar
                    className={classNames(classes.header)}>
                    <div className={classes.title}>
                        <Typography variant="title" id="tableTitle">
                            Listado FAQs
                        </Typography>
                        <Button
                            variant="fab"
                            color="primary"
                            aria-label="Agregar"
                            className={classes.button}
                            onClick={() => this.onCreateItem()}>
                            <AddIcon />
                        </Button>
                    </div>
                    <div className={classes.search}>
                        <div className={classes.searchIcon}>
                            <SearchIcon />
                        </div>
                        <InputBase
                            placeholder="Search…"
                            classes={{
                                root: classes.inputRoot,
                                input: classes.inputInput,
                            }}
                            onKeyPress={(e) => {
                                if (e.key === 'Enter') {
                                    this.onSearchChange(e, e.target.value);
                                }
                            }}
                        />
                    </div>
                </Toolbar>
                <FaqTable
                    collection={collection}
                    changeSortHandler={this.onSortChange}
                    changePageHandler={(event, page) => this.onPageChange(event, page)}
                    changeRowsPerPageHandler={(event) => this.onRowsPerPageChange(event)}
                    editRowHandler={(row) => this.onEditItem(row)}
                    deleteRowHandler={(row) => this.onDeleteItem(row)}
                    selectRowHandler={(row) => this.onSelectItem(row)}
                />
            </Paper>}

            {
                formData &&
                <Paper className={classes.root}>
                    <Toolbar
                        className={classNames(classes.header)}>
                        <div className={classes.title}>
                            { formData.Id === '00000000-0000-0000-0000-000000000000' && 
                            <Typography variant="title" id="tableTitle">
                                Nuevo FAQ
                            </Typography>
                            }
                            { formData.Id !== '00000000-0000-0000-0000-000000000000' && 
                            <Typography variant="title" id="tableTitle">
                                Edición FAQ
                            </Typography>
                            }
                        </div>
                    </Toolbar>
                    <FaqForm
                        formData={formData} errors={errors}
                        saveHandler={(item) => this.onSave(item)}
                        cancelHandler={() => this.onCancel()}
                    />
                </Paper>
            }

            {
                itemToRemove &&
                <HuaConfirmationDialog
                    title="Eliminar FAQ"
                    open={true}
                    body={`Seguro de eliminar la FAQ ${itemToRemove.Name}?`}
                    closeHandler={this.onDeleteCancel}
                    yesHandler={this.onDeleteConfirm}
                    noHandler={this.onDeleteCancel}
                />
            }
        </div>;
    }
}

FaqPage.propTypes = {
    classes: PropTypes.object.isRequired,
    fetchFaqs: PropTypes.func.isRequired,
    fetchFaqById: PropTypes.func.isRequired,
    createFaq: PropTypes.func.isRequired,
    updateFaq: PropTypes.func.isRequired,
    deleteFaq: PropTypes.func.isRequired
}

export default connect(
    state => {
        return {
            authentication: state.authentication
        };
    },
    {
        fetchFaqs: FaqActions.fetchPageAction,
        fetchFaqById: FaqActions.fetchByIdAction,
        createFaq: FaqActions.createAction,
        updateFaq: FaqActions.updateAction,
        deleteFaq: FaqActions.deleteAction,
        showError: showError,
        showSuccess: showSuccess
    }
)(withStyles(styles)(FaqPage));