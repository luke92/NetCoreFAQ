﻿import Constants from '../constants';

export function logoutAction() {
    return dispatch => {
        dispatch({ type: Constants.ActionTypes.LOGOUT });
    }
}