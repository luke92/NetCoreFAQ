﻿import Constants from '../constants';
import CreateCrudApi from '../factories/crudApiFactory';
import {
    fetchPageActionFactory,
    fetchByIdActionFactory,
    createActionFactory,
    updateActionFactory,
    deleteActionFactory
} from '../factories/crudActionsFactory';

const entityCrudApi = CreateCrudApi(Constants.Entities.Faq);

const FaqActions = {
    fetchPageAction: fetchPageActionFactory(Constants.Entities.Faq, entityCrudApi),
    fetchByIdAction: fetchByIdActionFactory(Constants.Entities.Faq, entityCrudApi),
    createAction: createActionFactory(Constants.Entities.Faq, entityCrudApi),
    updateAction: updateActionFactory(Constants.Entities.Faq, entityCrudApi),
    deleteAction: deleteActionFactory(Constants.Entities.Faq, entityCrudApi)
};

export default FaqActions;