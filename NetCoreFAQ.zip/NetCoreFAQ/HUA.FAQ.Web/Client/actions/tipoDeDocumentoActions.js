import Constants from '../constants';
import { API_URL_SEGURIDAD } from '../api/apiProxy';
import { executeApiCall } from '../api/apiProxy';

const TipoDeDocumentoActions = {
    fetchPageAction: function () {
        return dispatch => {
            return new Promise((resolve, reject) => {

                dispatch({ type: Constants.ActionTypes.FETCH_PAGE_STARTED(Constants.Entities.TipoDeDocumento) });
                {
                    executeApiCall('', 'GET', '', API_URL_SEGURIDAD + '/v1/tipodedocumento').
                        then(
                            (response) => {
                                dispatch({ type: Constants.ActionTypes.FETCH_PAGE_SUCCEED(Constants.Entities.TipoDeDocumento), payload: { result: response } });
                                resolve(response);
                            },
                            (response) => {
                                reject(response);
                            }
                    );
                }
            });
        };
    }
};

export default TipoDeDocumentoActions;