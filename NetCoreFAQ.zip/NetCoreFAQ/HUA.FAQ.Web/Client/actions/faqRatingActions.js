﻿import Constants from '../constants';
import CreateCrudApi from '../factories/crudApiFactory';
import {
    fetchByIdActionFactory,
    } from '../factories/crudActionsFactory';

const entityCrudApi = CreateCrudApi(Constants.Entities.FaqRating);

const FaqRatingActions = {
    addRating: fetchByIdActionFactory(Constants.Entities.Faq, entityCrudApi)
};

export default FaqRatingActions;