﻿import Constants from '../constants';
import { executeApiCall } from '../api/apiProxy';

export function loginAction(documentoTipo, documentoNumero, password) {
    return dispatch => {
        return new Promise((resolve, reject) => {
            dispatch({ type: Constants.ActionTypes.LOGIN_STARTED });

            executeApiCall('authentication', 'POST', {
                tipoDeDocumentoId: documentoTipo,
                numeroDeDocumento: documentoNumero,
                password: password
            })
            .then(
                (response) => {
                    dispatch({ type: Constants.ActionTypes.LOGIN_SUCCED, payload: response });
                    resolve(response);
                },
                (response) => {
                    dispatch({ type: Constants.ActionTypes.LOGIN_FAILED, payload: response });
                    reject(response);
                }
            );
        });
    }
}