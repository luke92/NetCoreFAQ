﻿import Constants from '../constants';
import CreateCrudApi from '../factories/crudApiFactory';
import {
    fetchPageActionFactory,
    fetchByIdActionFactory,
    createActionFactory,
    updateActionFactory,
    deleteActionFactory
    } from '../factories/crudActionsFactory';

const entityCrudApi = CreateCrudApi(Constants.Entities.Tag);

const TagActions = {

    fetchPageAction: fetchPageActionFactory(Constants.Entities.Tag  , entityCrudApi),
    fetchByIdAction: fetchByIdActionFactory(Constants.Entities.Tag, entityCrudApi),
    createAction: createActionFactory(Constants.Entities.Tag, entityCrudApi),
    updateAction: updateActionFactory(Constants.Entities.Tag, entityCrudApi),
    deleteAction: deleteActionFactory(Constants.Entities.Tag, entityCrudApi)
};

export default TagActions;