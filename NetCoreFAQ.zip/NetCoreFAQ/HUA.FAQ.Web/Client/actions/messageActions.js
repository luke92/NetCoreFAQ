﻿import Constants from '../constants';

export function closeMessager() {
    return dispatch => {
        dispatch({ type: Constants.ActionTypes.MESSAGER_CLOSE });
    }
}

export function showError(Messages) {
    return dispatch => {
        dispatch({ type: Constants.ActionTypes.MESSAGER_SHOW_ERROR, payload: Messages });
    }
}

export function showInfo(Messages) {
    return dispatch => {
        dispatch({ type: Constants.ActionTypes.MESSAGER_SHOW_INFO, payload: Messages });
    }
}

export function showWarning(Messages) {
    return dispatch => {
        dispatch({ type: Constants.ActionTypes.MESSAGER_SHOW_WARNING, payload: Messages });
    }
}

export function showSuccess(Messages) {
    return dispatch => {
        dispatch({ type: Constants.ActionTypes.MESSAGER_SHOW_SUCCESS, payload: Messages });
    }
}