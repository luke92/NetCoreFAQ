﻿import Constants from '../constants';
import CreateCrudApi from '../factories/crudApiFactory';
import {
    fetchPageActionFactory,
    fetchByIdActionFactory,
    createActionFactory,
    updateActionFactory,
    deleteActionFactory
} from '../factories/crudActionsFactory';

const entityCrudApi = CreateCrudApi(Constants.Entities.Category);

const CategoryActions = {
    fetchPageAction: fetchPageActionFactory(Constants.Entities.Category, entityCrudApi),
    fetchByIdAction: fetchByIdActionFactory(Constants.Entities.Category, entityCrudApi),
    createAction: createActionFactory(Constants.Entities.Category, entityCrudApi),
    updateAction: updateActionFactory(Constants.Entities.Category, entityCrudApi),
    deleteAction: deleteActionFactory(Constants.Entities.Category, entityCrudApi)
};

export default CategoryActions;