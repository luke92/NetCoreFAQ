﻿import Constants from '../constants';

var defaultState = {
    collection: {
        count: 0,
        filter: '',
        orderBy: '',
        items: [],
        page: 1,
        pageSize: Constants.Defaults.PageSize,
        pages: 0,
        fetchStatus: Constants.FetchStatus.Pristine
    },
    Errors: []
};

export default function (state = defaultState, action) {
    const reducerEntity = Constants.Entities.TipoDeDocumento;
    var newState = { ...state };

    switch (action.type) {
        case Constants.ActionTypes.FETCH_PAGE_STARTED(reducerEntity):
            newState.collection.fetchStatus = Constants.FetchStatus.Fetching;
            break;

        case Constants.ActionTypes.FETCH_PAGE_SUCCEED(reducerEntity):
            newState.collection = Object.assign(
                {},
                newState.collection,
                action.payload.result.Data,
                {
                    fetchStatus: Constants.FetchStatus.Loaded
                }
            );
            break;

        case Constants.ActionTypes.FETCH_PAGE_FAILED(reducerEntity):
            newState.collection.fetchStatus = Constants.FetchStatus.Error;
            newState.Errors = action.payload.result.Errors;
            break;
    }

    return newState;
}