﻿import { combineReducers } from 'redux';

//import usersReducer from "./usersReducer";
//import discrepanciasSummaryReducer from "./discrepanciasSummaryReducer";
import authenticationReducer from "./authenticationReducer";
import tipoDeDocumentoReducer from "./tipoDeDocumentoReducer";
import messagerReducer from "./messagerReducer";
//import discrepanciasDetailsReducer from "./discrepanciasDetailsReducer";
//import subTiposDePagoReducer from "./subtiposPagoReducer";
//import tiposDePagoReducer from './tiposPagoReducer';
//import categoríasReducer from './categoríasReducer';
//import estacionesReducer from './estacionesReducer';
//import viasReducer from './viasReducer';
//import sentidosReducer from './sentidosReducer';
//import transitosReducer from './transitosReducer';
//import reporteTransitosReducer from './reporteTransitosReducer';
//import turnosReducer from './turnosReducer';
//import liquidacionesReducer from './liquidacionesReducer';

export default combineReducers({
    authentication: authenticationReducer,
    tipoDeDocumento: tipoDeDocumentoReducer,
    messager: messagerReducer
    //users: usersReducer,
    //discrepanciasSummary: discrepanciasSummaryReducer,
    //discrepanciasDetails: discrepanciasDetailsReducer,
    //subtiposPago: subTiposDePagoReducer,
    //tiposPago: tiposDePagoReducer,
    //categorías: categoríasReducer,
    //estaciones: estacionesReducer,
    //vias: viasReducer,
    //sentidos: sentidosReducer,
    //transitos: transitosReducer,
    //reporteTransitos: reporteTransitosReducer,
    //turnos: turnosReducer,
    //liquidaciones: liquidacionesReducer
});