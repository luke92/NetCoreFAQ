﻿import Constants from '../constants';

var defaultState = {
    open: false,
    type: Constants.MessageTypes.None,
    messages: []
};

export default function (state = defaultState, action) {
    var newState = { ...state };

    switch (action.type) {
        case Constants.ActionTypes.MESSAGER_CLOSE:
            newState = {
                messages: [],
                type: Constants.MessageTypes.None,
                open: false
            }
            break;

        case Constants.ActionTypes.MESSAGER_SHOW_ERROR:
            newState = {
                messages: action.payload,
                type: Constants.MessageTypes.Error,
                open: true
            };
            break;

        case Constants.ActionTypes.MESSAGER_SHOW_INFO:
            newState = {
                messages: action.payload,
                type: Constants.MessageTypes.Info,
                open: true
            };
            break;

        case Constants.ActionTypes.MESSAGER_SHOW_WARNING:
            newState = {
                messages: action.payload,
                type: Constants.MessageTypes.Warning,
                open: true
            };
            break;

        case Constants.ActionTypes.MESSAGER_SHOW_SUCCESS:
            newState = {
                messages: action.payload,
                type: Constants.MessageTypes.Success,
                open: true
            };
            break;
    }

    return newState;
}