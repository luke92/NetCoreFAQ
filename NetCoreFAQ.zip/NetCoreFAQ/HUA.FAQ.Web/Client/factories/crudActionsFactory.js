﻿import Constants from '../constants';

/* This constructor function generates the default actions interface
    used to getPage, getById, save, add, edit and cancel operations.
    It receives the 'entity' for which it will generete the actions and
    the api provider which should implement getAll, getById and save operations */
export function fetchPageActionFactory(entityName, apiProvider) {
    return function (page, pageSize, filter, orderBy) {
        return dispatch => {
            return new Promise((resolve, reject) => {
                dispatch({ type: Constants.ActionTypes.FETCH_PAGE_STARTED(entityName) });

                apiProvider.getPage(page, pageSize, filter, orderBy).then(
                    (response) => {
                        dispatch({ type: Constants.ActionTypes.FETCH_PAGE_SUCCEED(entityName), payload: { result: response } });
                        resolve(response);
                    },
                    (response) => {
                        dispatch({ type: Constants.ActionTypes.FETCH_PAGE_FAILED(entityName), payload: { result: response } });
                        reject(response);
                    }
                );
            });
        }

    }
};

export function fetchByIdActionFactory(entityName, apiProvider) {
    return function(Id) {
        return dispatch => {
            return new Promise((resolve, reject) => {
                dispatch({ type: Constants.ActionTypes.FETCH_BY_ID_STARTED(entityName), payload: Id });

                apiProvider.getById(Id).then(
                    (response) => {
                        dispatch({ type: Constants.ActionTypes.FETCH_BY_ID_SUCCEED(entityName), payload: { result: response } });
                        resolve(response);
                    },
                    (response) => {
                        dispatch({ type: Constants.ActionTypes.FETCH_BY_ID_FAILED(entityName), payload: { result: response, id: Id } });
                        reject(response);
                    }
                );
            });
        }
    }
};

export function createActionFactory(entityName, apiProvider) {
    return function (model) {
        return dispatch => {
            return new Promise((resolve, reject) => {
                dispatch({ type: Constants.ActionTypes.CREATE_STARTED(entityName), payload: model });
                apiProvider.create(model).then(
                    (response) => {
                        dispatch({ type: Constants.ActionTypes.CREATE_SUCCEED(entityName), payload: { result: response, entity: model } });
                        resolve(response);
                    },
                    (response) => {
                        dispatch({ type: Constants.ActionTypes.CREATE_FAILED(entityName), payload: { result: response, entity: model } });
                        reject(response);
                    }
                );
            });
        }
    }
};

export function updateActionFactory(entityName, apiProvider) {
    return function (model) {
        return dispatch => {
            return new Promise((resolve, reject) => {
                dispatch({ type: Constants.ActionTypes.UPDATE_STARTED(entityName), payload: model });

                apiProvider.update(model).then(
                    (response) => {
                        dispatch({ type: Constants.ActionTypes.UPDATE_SUCCEED(entityName), payload: { result: response, entity: model } });
                        resolve(response);
                    },
                    (response) => {
                        dispatch({ type: Constants.ActionTypes.UPDATE_FAILED(entityName), payload: { result: response, entity: model } });
                        reject(response);
                    }
                );
            });
        }
    }
};

export function deleteActionFactory(entityName, apiProvider) {
    return function (model) {
        return dispatch => {
            return new Promise((resolve, reject) => {
                dispatch({ type: Constants.ActionTypes.DELETE_STARTED(entityName) });

                apiProvider.delete(model).then(
                    (response) => {
                        dispatch({ type: Constants.ActionTypes.DELETE_SUCCEED(entityName), payload: { result: response, entity: model } });
                        resolve(response);
                    },
                    (response) => {
                            dispatch({ type: Constants.ActionTypes.DELETE_FAILED(entityName), payload: { result: response, entity: model } });
                            reject(response);
                    }
                );
            });
        }
    }
};