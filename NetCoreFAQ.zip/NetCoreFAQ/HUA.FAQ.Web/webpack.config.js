﻿/// <binding ProjectOpened='Watch - Development' />
var path = require('path');
var webpack = require('webpack');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CleanWebpackPlugin = require('clean-webpack-plugin');

module.exports = {
    entry: { main: './Client/main.js' },
    mode: 'development',
    output: {
        path: path.resolve(__dirname, "./wwwroot/static/scripts"),
        publicPath: 'static/scripts/',
        filename: 'app.js'
    },
    devServer: {
        historyApiFallback: {
            index: '/index.html'
        },
        hot: true,
        stats: 'errors-only',
        clientLogLevel: 'error'
    },
    plugins: [
        new CleanWebpackPlugin(
            [
                path.resolve(__dirname, "./wwwroot/static/scripts")
            ]
        ),
        new webpack.ProvidePlugin({
            $: "jquery",
            jQuery: "jquery"
        }),
        new webpack.NamedModulesPlugin(),
        new webpack.DefinePlugin({
          'process.env': {
            NODE_ENV: JSON.stringify('development')
          }
        })
    ],
    module: {
        rules: [
            {
                test: /.(jsx|js)?$/,
                exclude: /node_modules/,
                use: 'babel-loader'
            },
            {
                test: /\.css$/,
                use: [
                       { loader: 'style-loader' },
                       { loader: 'css-loader' }
                     ],
            }, 
            {
                test: /\.woff(\?v=\d+\.\d+\.\d+)?$/,
                use: "url-loader?limit=10000&mimetype=application/font-woff"
            }, 
            {
                test: /\.woff2(\?v=\d+\.\d+\.\d+)?$/,
                use: "url-loader?limit=10000&mimetype=application/font-woff"
            }, 
            {
                test: /\.ttf(\?v=\d+\.\d+\.\d+)?$/,
                use: "url-loader?limit=10000&mimetype=application/octet-stream"
            }, 
            {
                test: /\.eot(\?v=\d+\.\d+\.\d+)?$/,
                use: "file-loader"
            }, 
            {
                test: /\.svg(\?v=\d+\.\d+\.\d+)?$/,
                use: "url-loader?limit=10000&mimetype=image/svg+xml"
            }
        ]
    }
};