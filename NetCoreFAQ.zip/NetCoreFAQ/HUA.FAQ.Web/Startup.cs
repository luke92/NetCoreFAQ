﻿using System;
using System.IO;
using HUA.FAQ.Business;
using HUA.FAQ.Business.Modules.Authentication;
using HUA.FAQ.Business.Modules.Category;
using HUA.FAQ.Business.Modules.Faq;
using HUA.FAQ.Business.Modules.Tag;
using HUA.FAQ.Data;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SpaServices.Webpack;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Swashbuckle.AspNetCore.Swagger;
using Microsoft.AspNetCore.Identity;
using Microsoft.IdentityModel.Tokens;
using System.Text;
using HUA.Core.Settings;
using HUA.EstructuraHospitalaria.Business;
using HUA.FAQ.Business.Modules.Mail;

namespace HUA.FAQ.Web
{
    ///
    public class Startup
    {
        ///
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }
        ///
        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        ///
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_1).AddJsonOptions(options =>
            {
                options.SerializerSettings.ContractResolver
                    = new Newtonsoft.Json.Serialization.DefaultContractResolver();
            });

            services.AddDbContext<FAQContext>(
                options => options.UseSqlServer(Configuration["ConnectionStrings:FAQConnection"])
            );

            // register the Swagger generator, defining one or more Swagger documents
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc(Configuration["App:Version"], new Info { Title = Configuration["App:Name"], Version = Configuration["App:Version"] });
                c.IncludeXmlComments(string.Format(@"{0}\HUA.FAQ.Web.xml", System.AppDomain.CurrentDomain.BaseDirectory));
            });


            // register application modules
            services.AddScoped<FaqModule>();
            services.AddScoped<AuthenticationModule>();
            services.AddScoped<CategoryModule>();
            services.AddScoped<TagModule>();
            services.AddScoped<ISeguridadService, SeguridadService>();
            services.AddSingleton<IMailModule, MailModule>();

            // Agrego los datos de seguridad
            services.Configure<SecuritySettings>(Configuration.GetSection("Security"));
            services.Configure<AuthenticationSettings>(Configuration.GetSection("Authentication"));
            //services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            //    .AddJwtBearer(options =>
            //    {
            //        options.TokenValidationParameters = new TokenValidationParameters
            //        {
            //            ValidateIssuer = true,
            //            ValidateAudience = true,
            //            ValidateLifetime = true,
            //            ValidateIssuerSigningKey = true,
            //            ValidIssuer = Configuration["Authentication:Issuer"],
            //            ValidAudience = Configuration["Authentication:Audience"],
            //            IssuerSigningKey = new SymmetricSecurityKey(
            //                Encoding.UTF8.GetBytes(Configuration["Authentication:SecurityKey"])
            //            )
            //        };
            //    });


            services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
                .AddJwtBearer(options =>
                 options.TokenValidationParameters = new TokenValidationParameters
                 {
                     ValidateIssuer = true,
                     ValidateAudience = true,
                     ValidateLifetime = true,
                     ValidateIssuerSigningKey = true,
                     ValidIssuer = Configuration["JWT:Issuer"],
                     ValidAudience = Configuration["JWT:Audience"],
                     IssuerSigningKey = new SymmetricSecurityKey(
                     Encoding.UTF8.GetBytes(Configuration["JWT:Secret"])),
                     ClockSkew = TimeSpan.Zero
                 });
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        ///
        public void Configure(
            IApplicationBuilder app, 
            IHostingEnvironment env,
            IOptions<SecuritySettings> securitySettings,
            ISeguridadService seguridadService,
            FAQContext faqContext)
        {

            if (env.IsDevelopment())
            {
                // Fix problemas con proxy
                AppContext.SetSwitch("System.Net.Http.UseSocketsHttpHandler", false);

                app.UseDeveloperExceptionPage();
                app.UseWebpackDevMiddleware(new WebpackDevMiddlewareOptions
                {
                    HotModuleReplacement = true,
                    ReactHotModuleReplacement = true
                });
            }
            else
            {
                app.UseHsts();
            }

            app.UseHttpsRedirection();

            app.UseAuthentication();

            app.UseMvc();

            if (env.IsDevelopment())
            {
                // Enable middleware to serve generated Swagger as a JSON endpoint.
                app.UseSwagger();

                // Enable middleware to serve swagger-ui specifying the Swagger JSON endpoint.
                app.UseSwaggerUI(c =>
                {
                    c.SwaggerEndpoint("/swagger/" + Configuration["App:Version"] + "/swagger.json", Configuration["App:Name"]);
                });
            }

            app.Use(async (context, next) => {
                await next();
                if (context.Response.StatusCode == 404 &&
                   !Path.HasExtension(context.Request.Path.Value) &&
                   !context.Request.Path.Value.StartsWith("/api/"))
                {
                    context.Request.Path = "/index.html";
                    await next();
                }
            });

            app.UseStaticFiles();
            app.UseMvc();

            // initialize database context
            BusinessInitializer.InitializeDatabase(faqContext);

            // initialize bussiness context
            BusinessInitializer.InitializeMappings();

            // register application at seguridad
            BusinessInitializer.RegisterApplicationInSecurityServer(securitySettings.Value, seguridadService);
        }
    }
}